<footer class="sixteen columns row foot">
	<div id="footer-wrap">
		 <?php dynamic_sidebar('footer-widgets'); ?>
		 <span id="wp-link">Proudly Powered By <a href="http://www.wordpress.org" target="_blank">WordPress</a> | <a href="http://www.wordpress.org/themes/technews">TechNews Theme</a></span>
	 </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>