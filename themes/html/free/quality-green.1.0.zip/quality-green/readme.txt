Quality Green is the child version of Quality theme.


===== Change Log =========
= 1.0 =
1. Added template Blog Full width
2. Added template Page Full Width
3. Added template fullwidth page

= 0.1 =
released