<?php
/*
Template Name: Front Page
*/

get_header(); ?>


	<div class="entry-content">
		<?php the_content(); ?>
	</div><!-- .entry-content -->


<?php get_footer(); ?>
