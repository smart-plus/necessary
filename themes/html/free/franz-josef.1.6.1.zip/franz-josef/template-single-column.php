<?php
/**
 * Template name: Single column
 */
__( 'Single column', 'franz-josef' );
get_template_part( 'page' ); 