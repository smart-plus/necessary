Theme Name: Being Hueman
	Theme URI: http://designchapter.com/being-hueman/
	Description: child theme for Hueman theme.
	Author: Boxspin
	Author URI: http://boxspin.com
	Template: hueman
	Version: 1.0.0
    Description: Hueman Child Theme - with Author added to the frontpage post display. <a href="http://alxmedia.se/themes/hueman/">Hueman</a> is a responsive 100% high resolution theme for blogs and magazines. Unique toggle sidebars give a great browsing and reading experience on both tablet and mobile. The feature list is long: Unlimited topbar, header, footer and accent colors, unlimited widget areas, 0-2 sidebars to the left or right that can be uniquely specified for each page or post, 300px / 220px fixed width sidebars, 0-4 footer widget columns, almost zero layout images, related posts and post nav, featured story or slider, 10 post formats, good SEO, 3 flexible custom widgets, localisation support, social links, logo upload and many more useful admin panel features.

    Tags: light, one-column, two-columns, three-columns, right-sidebar, left-sidebar, fluid-layout, fixed-layout, custom-colors, custom-menu, featured-images, flexible-header, full-width-template, post-formats, sticky-post,           theme-options, threaded-comments, translation-ready                                 

	Copyright: (c) 2013 Alexander "Alx" Agnarson
	License: GNU General Public License v3.0
	License URI: http://www.gnu.org/licenses/gpl-3.0.html


== Resources ==
* Images used in live preview and screenshot are from - http://skitterphoto.com/ (Creative Commons CC0 1.0) and http://jaymantri.com/ (Creative Commons CC0 1.0)


8th July 2014 - 1.0.0
===========================================================
- Theme released
- Added author to the frontpage post display as per request from - https://wordpress.org/support/topic/show-authors-name-on-the-homepage?replies=1
* All other resources are as per defined in the parent theme