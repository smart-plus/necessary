-----------------------------------------------
License:
-----------------------------------------------

Coupon WordPress Theme, Copyright 2014 Ketchupthemes.com
Coupon is distributed under the terms of the GNU GPL-2.0+

-----------------------------------------------
Scripts:
-----------------------------------------------
All scripts in Coupon are licensed under the terms of the GNU GPL-2.0+, while others are licensed under the MIT License.
Twitter Bootstrap boilerplate, is distributed under the MIT Licence.
SlickNav jQuery Plugin is licended under the MIT Licence
Bootstrap Navwalker is licensed under the terms of GPL-2.0+

-----------------------------------------------
Images
-----------------------------------------------
http://pixabay.com/en/cardboard-box-paper-old-close-up-314504/ -- CC0 License
http://pixabay.com/en/bag-buying-carry-customer-cute-15709/ -- CC0 License
Header image and coupon logo (logo1.jpg) are our own creation and could be download through the theme uri
-----------------------------------------------
Fonts
-----------------------------------------------
Open Sans - Apache License, version 2.0.
Licence for fontawesome font icons - License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License).
License for GLYPHICONS Halflings in Twitter Bootstrap - GLYPHICONS Halflings are also a part of Bootstrap from Twitter, and they are released under the same license as Bootstrap.
Licence for Elegant Fonts  GPLv2 & MIT

-----------------------------------------------
Menu
-----------------------------------------------
Menu doesn't support more than 3 levels deep

-----------------------------------------------
Change Log:
-----------------------------------------------
First Release
= 1.0. =
First Release
= 1.1 =
Updates
- Renaming Sidebars for better readability
- Fix padding in footer sidebar
- Fix PHP incompatibilities
- Activate Sidebars only when active
- Remove error in the footer area
- Small Code Refactoring in certain pages
= 1.2 =
- Better Description and Tags Added
= 1.3 =
- Theme URI error Fixed.
- Better CSS Styling to many different elements such as tables, lists etc.
- More readable code.
- Screenshot changed
= 1.4 =
- Screenshot Changed
= 1.4.1 =
- Minor bug fixes
= 1.4.2 =
- Translation Update
= 1.4.3 =
- Minor Bug Fixes