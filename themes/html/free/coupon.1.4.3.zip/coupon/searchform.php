<form class="form-group" role="search" method="get" id="searchform" action="<?php echo esc_url(home_url( '/' )); ?>">
  <div id="sbox">
       <input type="text" value="" class="form-control"  name="s" id="s">
       <button type="submit" id="searchsubmit">
        <i class="icon_search"></i>
       </button>
  </div>
</form>