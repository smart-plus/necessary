<?php 
get_header();
$classes = ing_sidebar_classes();
$ing_options = ingleside_options();

ing_update_excon($ing_options);

echo ing_cta($ing_options); 

ing_homepage($classes, $ing_options);

get_footer(); 
?>