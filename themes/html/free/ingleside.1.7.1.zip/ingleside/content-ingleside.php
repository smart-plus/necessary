<?php 
$prev_post = get_previous_post();
$ing_options = ingleside_options();
if(has_post_thumbnail()){
	if( has_post_thumbnail( $prev_post->ID ) === true ){
		$bborder = '';
	}elseif( has_post_thumbnail( $prev_post->ID ) === false ){
		$bborder = 'bborder';
	}
}else{
	$bborder = 'bborder';
}

$essentials = ing_essentials();

$cta = null;
if( isset($essentials['sidebar_location']) ){
	if( $essentials['sidebar_location'] == 'none' && ing_cta($ing_options) != '' ){
		$cta = ' ing-cta-buffer';
	}
}else{
	$cta = ' ing-cta-buffer';
}

$excon = array();

if(is_customize_preview()){
	$excon = get_post_meta( get_the_ID(), 'ing_home_temp_excon', true );
}else{
	$excon = get_post_meta( get_the_ID(), 'ing_home_excon', true );
}

$justify = '';
if( !empty($excon) ){
	if($excon == "con"){
		$justify = 'style="text-align: left;"';
	}elseif($excon == "ex"){
		$justify = 'style="text-align: center;"';
	}
}else{
	$justify = '';
}
		
?>
<article id="post-<?php the_ID(); ?>" <?php post_class($bborder); ?> itemscope itemtype="http://schema.org/Article">
	<?php 
	if ( has_post_thumbnail() ) {
	?>
	<figure class="featured-thumb<?php echo $cta;?>">
		<a href="<?php echo esc_url( get_permalink() );?>" rel="bookmark"><?php the_post_thumbnail('featured'); ?></a>
	</figure>
<?php } ?>
	<?php 
	if ( is_sticky() && is_home() && ! is_paged() ) {
		the_title( '<h2 class="entry-title" itemprop="headline"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark"><strong>', '</strong></a></h2>' ); 
	}else{
		the_title( '<h2 class="entry-title" itemprop="headline"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); 
	}
	?>
	<div class="entry-content" itemprop="articleBody" <?php echo $justify;?>>
		<?php if( 'page' != get_post_type( get_the_ID() ) ){ ?>
		<div class="entry-meta">
			<span class="entry-date"><a href="<?php echo esc_url( get_permalink() );?>" rel="bookmark"><time class="entry-date published updated" datetime="<?php echo esc_attr( get_the_date( 'c' ) );?>"><?php echo esc_html( get_the_date() );?></time></a></span> <span class="byline"><span class="author vcard"><a class="url fn n" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) );?>" rel="author"><?php echo get_the_author();?></a></span></span>
		</div>
		<?php } ?>
		<?php 
		if( empty($excon) ){
			the_excerpt(); 
		}else{
			if($excon == "con"){
				the_content(); 
			}elseif($excon == "ex"){
				the_excerpt(); 
			}
		}
		?>
	</div>
	<div class="entry-footer clearfix">
	  <ul class="meta stack-for-small secondary button-group radius round">
	  	<?php 
	  	if( isset($ing_options['home']['ingleside']['entry_footer']) )
	  	{	
	  		if( !empty($ing_options['home']['ingleside']['entry_footer']) )
	  		{
	  	 if ( comments_open() ) { ?>
	  	<li class="comment-count">
	  		<?php comments_popup_link(
	  		__( 'Post a reply', 'ingleside' ), 
	  		__( '1 reply', 'ingleside' ), 
	  		__( '% replies', 'ingleside' ),
	  		'tiny button'); ?>
	  	</li>
	    <?php } ?>
	    <?php echo ing_cats(); ?>
	    <li>
	    	<a href="<?php echo esc_url( get_permalink() );?>" class="readmore tiny button success"><?php echo __('Read More','ingleside');?></a>
	    </li>
	    <?php 
	    	}
	    }
	     edit_post_link( __( 'Edit', 'ingleside' ), '<li class="edit">', '</li>' ); ?>
	  </ul>
	</div>
</article>