<?php
if ( ! isset( $content_width ) ) {$content_width = 1280;}

add_action( 'after_setup_theme', 'ingleside_setup' );

function ingleside_setup()
{
	add_action( 'init', 'register_menu' );
	add_action( 'wp_footer', 'footer_js' );
	add_action( 'wp_enqueue_scripts','register_scripts' );
	add_action( 'widgets_init', 'ingleside_widgets_init' );
		
	//Theme Support
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-background' );
	add_theme_support( 'menus' );
	add_theme_support( 'automatic-feed-links' );
	
	add_action( 'admin_enqueue_scripts', 'ing_custom_wp_admin_style' );
	add_filter( 'wp_title', 'ingleside_home_title' );
	add_filter( 'embed_oembed_html', 'ing_embed_oembed_html', 99, 4 );
	
	load_theme_textdomain( 'ingleside', get_template_directory() . '/languages' );
	
	add_editor_style(get_template_directory_uri().'/css/custom-editor-style.css' );
	
	include( 'includes/ingleside.php' );
	include( 'includes/backend/ing_customizer.php' );

	if(is_admin()){
		include( 'includes/backend/ing_editor.php' );
	}
}

if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ){
	wp_enqueue_script( 'comment-reply' );
}

add_image_size( 'featured', 1000, 280, true ); //(cropped)

function register_menu() {
	register_nav_menu( 'main-menu', __( 'Main Menu','ingleside' ) );
}

function register_scripts()
{
	$custom_scripts = array(
		'js' => get_template_directory_uri()."/js/",
		'css' => get_template_directory_uri()."/css/",
	);
    
    wp_enqueue_style( 'ingleside-style', $custom_scripts['css'].'/ingleside.css','','1');
    wp_enqueue_style( 'parent-theme', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'f-icons', $custom_scripts['css'].'/foundation-icons.min.css');
	wp_enqueue_style( 'lato', "http://fonts.googleapis.com/css?family=Lato:300");
	wp_enqueue_style( 'OpenSans', "http://fonts.googleapis.com/css?family=Open+Sans:300");
	
	wp_enqueue_script('modernizr',$custom_scripts['js'].'modernizr.min.js','','2.6.2');
	wp_enqueue_script('foundation',$custom_scripts['js'].'foundation.min.js',array( 'jquery' ),'5',true);
	wp_enqueue_script('easy',$custom_scripts['js'].'jquery.easing.1.3.min.js',array( 'jquery' ),'1.3',true);
	wp_enqueue_script('placeholders',$custom_scripts['js'].'placeholders.min.js',array( 'jquery' ),'1.0',true);
	wp_enqueue_script('inglesidejs',$custom_scripts['js'].'ingleside.min.js',array( 'jquery' ),'1.0',true);
	
	$essentials = ing_essentials();

	wp_localize_script( 'inglesidejs', 'inglesideEssentials', $essentials );

	if( is_home() && !$essentials['init']){
	
	wp_enqueue_script('parallax',$custom_scripts['js'].'parallax.min.js',array( 'jquery' ),'1.0',true);
	}
}

add_action( 'wp_enqueue_scripts', 'ingleside_child_styles', 20 );

function ingleside_child_styles() {
    wp_enqueue_style( 'child-theme', get_stylesheet_uri() );
}

function ing_custom_wp_admin_style() {
	wp_register_style( 'admin-gentium', 'http://fonts.googleapis.com/css?family=Gentium+Basic', false, '' );
}

function ingleside_widgets_init() 
{
	register_sidebar(array(
		'name' => 'Sidebar',
		'id' => 'sidebar-1',
		'before_widget' => '<div id="%1$s" class="ing-widgets %2$s">',
		'after_widget'  => '</div>',
		'description' => 'Sidebar.',
		'before_title'  => '<h3 class="widgettitle">',
		'after_title'   => '</h3>'
	));
	
	register_sidebar(array(
		'name' => 'Footer Area',
		'id' => 'ing-footer',
		'before_widget' => '<li id="%1$s" class="ing-widgets %2$s">',
		'after_widget'  => '</li>',
		'description' => 'Footer Widget Area.',
		'before_title'  => '<h3 class="widgettitle">',
		'after_title'   => '</h3>'
	));
}

add_action('wp_ajax_nopriv_top-height', 'ingleside_top_height');
add_action('wp_ajax_top-height', 'ingleside_top_height');

function ingleside_top_height()
{
	check_ajax_referer('lakeview', 'token');
	$ing_options = ingleside_options();
	
	if(!empty($_POST['height'])){
		$ing_options['topbar']['height'] = (int)$_POST['height'];
	}
	
	if(!empty($_POST['mobile_height'])){
		$ing_options['topbar']['mobile_height'] = (int)$_POST['mobile_height'];
	}
	
	delete_transient( 'ingleside_options' );
	update_option( 'ing_theme_options', $ing_options );

	exit();
}

add_action('ingleside_intro','ingleside_intro');

function ingleside_activated()
{
	add_option('ingleside_activation_check', 'set');
}

add_action( 'after_switch_theme', 'ingleside_activated' );

function ingleside_intro()
{
	$options = get_option( 'ing_theme_options' );
	$check = get_option('ingleside_activation_check');
	
	if ( 'set' !== $check )
	{
		if(is_customize_preview())
		{
			if( empty($options) )
			{
				echo '
				<div class="intro-preview">
					<div class="parallax-container" data-parallax="scroll" data-position="top" data-bleed="0" data-image-src="',get_template_directory_uri(),'/intro.jpg" data-natural-width="1900" data-natural-height="1267"></div>
					
					<a href="https://www.flickr.com/photos/leonfishman/7114897207" rel="nofollow" class="flickr-credit" target="_blank">IMG_5328 - Leon Fishman</a>
				</div>';
			}
		}
	}
}

function footer_js()
{
?>
<script type="text/javascript">
	jQuery(document).ready( function($){
		$(document).foundation();
	});
</script>
<?php
}

function ingleside_home_title( $title ){
	if( empty( $title ) && ( is_home() || is_front_page() ) ) {
		return get_bloginfo( 'name' ) . ' | ' . get_bloginfo( 'description' );
	}
	
	return $title;
}

function ing_embed_oembed_html( $html, $url, $attr, $post_id ) {
  return '<div class="flex-video">' . $html . '</div>';
}
?>