<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> itemscope itemtype="http://schema.org/Article">

	<h1 class="no-title"><?php _e( 'Nothing Found', 'ingleside' ); ?></h1>

	<div class="no-entry-content">
<p><?php _e( 'Apologies, but no results were found. Perhaps searching will help find a related post.', 'ingleside' ); ?></p>
			<?php get_search_form(); ?>
	</div>
</article>