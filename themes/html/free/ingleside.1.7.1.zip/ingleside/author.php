<?php get_header();
	$classes = ing_sidebar_classes();
?>
<div id="main-content" class="row collapse" <?php echo $classes['main-content'];?>>
	<div id="primary" class="<?php echo $classes['primary'];?>">
	<?php
	if( have_posts() )
	{
		the_post();
		?>
		<h1 class="archive-title"><?php printf( __( 'Author Archives: %s', 'ingleside' ), '<span class="vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( "ID" ) ) ) . '" title="' . esc_attr( get_the_author() ) . '" rel="me">' . get_the_author() . '</a></span>' ); ?></h1>
		<?php
		rewind_posts();
		
		if ( get_the_author_meta( 'description' ) )
		{ ?>
		<div class="author row">
			<div class="author-info large-12 large-centered medium-12 medium-centered columns clearfix">
				<div class="author-avatar left">
					<?php
					$author_bio_avatar_size = apply_filters( 'twentytwelve_author_bio_avatar_size', 68 );
					echo get_avatar( get_the_author_meta( 'user_email' ), $author_bio_avatar_size );
					?>
				</div><!-- .author-avatar -->
				<div class="author-description">
					<h2 class=""><?php printf( __( 'About %s', 'ingleside' ), get_the_author() ); ?></h2>
					<p><?php the_author_meta( 'description' ); ?></p>
				</div><!-- .author-description	-->
			</div><!-- .author-info -->
		</div>
		<?php
		} 
		
		while ( have_posts() )
		{
			the_post();
			
			get_template_part( 'content', 'archive' );
		}	
	}
	else
	{
		get_template_part( 'content', 'none' );
	}
	?>
	</div>
	<?php get_sidebar(); ?>
</div>
<?php get_footer();?>