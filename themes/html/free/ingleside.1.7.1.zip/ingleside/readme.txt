=== Ingleside ===
Tags: custom-colors, one-column, two-columns, right-sidebar, left-sidebar, responsive-layout, fluid-layout, custom-menu, full-width-template, theme-options, threaded-comments, editor-style, featured-images, featured-image-header, sticky-post, translation-ready, flexible-header, custom-background, rtl-language-support
Requires at least: 4.1
Tested up to: 4.1
Stable tag: 4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Ingleside is an HTML5 responsive blogging/informational theme built on ZURB Foundation. Ingleside’s mobile centric design adapts to various devices and displays ranging from desktops to mobile phones. Ingleside boasts many layout options such as logo uploads, follow me and sharing services, sidebar locations, Call to action/Hero Headers columns and most importantly, Palette Unlimited. Ingleside is also (WPML) Multilingual ready, W3C validated, comes with a child theme, SEO friendly, RTL support, retina ready, and cross browser supported starting from Internet Explorer 9 and up. Tested on PHP 5.3.29 and higher.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's ZIP file. Click Install Now.
3. Click Activate to use your new theme right away.

== Documentation ==
Please visit http://demos.wlcdesigns.com/ingleside/documentation/ for indept documentation.