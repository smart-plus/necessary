<?php get_header();
	$classes = ing_sidebar_classes();
?>
<div id="main-content" class="row collapse" <?php echo $classes['main-content'];?>>
	<div id="primary" class="<?php echo $classes['primary'];?>">
	<?php
	if( have_posts() )
	{
		?>
		<h1 class="archive-title"><?php printf( __( 'Category Archives: %s', 'ingleside' ), '<span>' . single_cat_title( '', false ) . '</span>' ); ?></h1>
		<?php if ( category_description() ) : // Show an optional category description ?>
				<div class="archive-meta"><?php echo category_description(); ?></div>
		<?php endif; ?>
		<?php	
		while ( have_posts() )
		{
			the_post();
			get_template_part( 'content', 'archive' );
		}
		?>
		<div class="ing-navigation clearfix">
			<div class="left"><?php previous_posts_link( '<i class="fi-previous"></i>' ); ?></div>
			<div class="right"><?php next_posts_link( '<i class="fi-next"></i>', '' ); ?></div>
		</div>
		<?php	
	}else{
		get_template_part( 'content', 'none' );
	}
	?>
	</div>
	<?php get_sidebar(); ?>
</div>
<?php get_footer();?>