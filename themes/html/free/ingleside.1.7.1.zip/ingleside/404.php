<?php get_header();
	$classes = ing_sidebar_classes();
?>
<div id="main-content" class="row collapse" <?php echo $classes['main-content'];?>>
	<div id="primary" class="<?php echo $classes['primary'];?>">
	<?php get_template_part( 'content', 'none' ); ?>
	</div>
	<?php get_sidebar(); ?>
</div>
<?php get_footer();?>