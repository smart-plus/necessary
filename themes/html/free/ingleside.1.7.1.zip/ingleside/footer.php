	<?php ing_footer(); ?>
	</div> <!-- end #wrap -->
	<?php wp_footer(); ?>
</body>
</html>