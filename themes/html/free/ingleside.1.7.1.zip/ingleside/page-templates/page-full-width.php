<?php
/**
 * Template Name: Full Width Page
 */

get_header();
$classes = ing_sidebar_classes();
?>
<div id="main-content" class="row collapse" <?php echo $classes['main-content'];?>>
	<div id="primary" class="large-12 medium-12 small-12 columns">
	<?php
	if(have_posts())
	{
		while ( have_posts() )
		{
			the_post();
			
			get_template_part( 'content','page' );
		}
	}else{
		get_template_part( 'content', 'none' );
	}
	?>
	</div>
</div>
<script type="text/javascript">
	jQuery(document).ready(function($){
		$("footer#bottom").css({"width":"100%"});	
	});
</script>
<?php get_footer();?>