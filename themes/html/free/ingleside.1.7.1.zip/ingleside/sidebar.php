<?php 
$classes = ing_sidebar_classes(); 
$ing_options = get_option('ing_theme_options');

if( isset($ing_options['sidebar']['location']) ){
	if( 'none' == $ing_options['sidebar']['location'] ) return;
}

?>
<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
<aside id="sidebar" class="<?php echo $classes['sidebar']; ?>" role="complementary">
<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside>
<?php endif ?>