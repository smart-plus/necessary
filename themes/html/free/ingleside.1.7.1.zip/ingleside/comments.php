<?php
	$current_user = wp_get_current_user();
	$commenter = wp_get_current_commenter();
	$req = get_option( 'require_name_email' );
	$aria_req = ( $req ? " aria-required='true'" : '' );

	$args = array(
	    'comment_field' =>  '<p class="comment-form-comment"><textarea id="comment" name="comment" cols="45" rows="8" placeholder="' . __( 'Comment', 'ingleside' ) .
    '" aria-required="true">' .
    '</textarea></p>',
		'logged_in_as' => '<p class="logged-in-as">' .
    sprintf(
    __( '<ul class="stack-for-small round button-group">
    	<li><a href="javascript:void(0)" class="button tiny secondary disabled">Logged in as</a></li> <li><a class="button tiny" href="%1$s">%2$s</a></li><li><a class="button tiny alert" href="%3$s" title="Log out of this account">Log out?</a></li></ul>' ),
      admin_url( 'profile.php' ),
       $current_user->display_name,
      wp_logout_url( apply_filters( 'the_permalink', get_permalink( ) ) )
    ) . '</p>',
    'comment_notes_after' => '<p class="form-allowed-tags panel">' .
    sprintf(
      __( 'You may use these <abbr title="HyperText Markup Language">HTML</abbr> tags and attributes: %s' ),
      ' <code>' . allowed_tags() . '</code>'
    ) . '</p>',
   'fields' => apply_filters( 'comment_form_default_fields', array(

    'author' =>
      '<p class="comment-form-author">
      	<input id="author" name="author" placeholder="' . __( 'Name', 'ingleside' ) . ( $req ? '*' : '' ) .'" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
      '" size="30"' . $aria_req . ' /></p>',

    'email' =>
      '<p class="comment-form-email">
      	<input id="email" name="email"  placeholder="' . __( 'Email', 'ingleside' ) . ( $req ? '*' : '' ) .'" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
      '" size="30"' . $aria_req . ' /></p>',

    'url' =>
      '<p class="comment-form-url">' .
      '<input id="url" name="url" type="text" placeholder="' .
      __( 'Website', 'ingleside' ) . '" value="' . esc_attr( $commenter['comment_author_url'] ) .
      '" size="30" /></p>'
    )
  ),
      
    );
	comment_form($args);
?>
<ol id="comments" class="comment list">
    <?php wp_list_comments( array( 'style' => 'ol' ) ); ?>
</ol>
<div class="ing-comment-navigation">
  <?php paginate_comments_links( array( 'type' => 'list' ) ); ?> 
</div>