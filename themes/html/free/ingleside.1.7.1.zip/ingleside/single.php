<?php
$classes = ing_sidebar_classes();
get_header() ?>
<div id="main-content" class="row collapse" <?php echo $classes['main-content'];?>>
	<div id="primary" class="<?php echo $classes['primary'];?>">
	<?php
	if(have_posts())
	{
		while ( have_posts() )
		{
			the_post();
			
			get_template_part( 'content' );
		}
	}else{
		get_template_part( 'content', 'none' );
	}
	?>
	</div>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>