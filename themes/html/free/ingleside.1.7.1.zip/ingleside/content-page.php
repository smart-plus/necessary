
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> itemscope itemtype="http://schema.org/Article">
		<?php
		if ( has_post_thumbnail() ) {
		?>
		<figure class="fthumb">
		<?php the_post_thumbnail( 'featured' ); ?>
		</figure>
		<?php } ?>
		<?php the_title( '<h1 class="entry-title" itemprop="headline">', '</h1>' ); ?>
		<div class="entry-content" itemprop="articleBody">
		<?php 
			the_content(); 
			wp_link_pages( array(
				'before'      => '<div class="ing-paging"><ul class="pagination page-links">',
				'after'       => '</ul></div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'nextpagelink'     => __( 'Next &raquo;', 'ingleside' ),
				'previouspagelink' => __( '&laquo; Previous', 'ingleside' ),
			) );
		?>
			<div class="entry-footer clearfix">
			<?php 
			edit_post_link( __( 'Edit', 'ingleside' ), '<div class="page-edit">', '</div>' );
			ing_sharing();
			ing_post_links();
			comments_template( '', true );
			?>
			</div>
		</div>
	</article>
