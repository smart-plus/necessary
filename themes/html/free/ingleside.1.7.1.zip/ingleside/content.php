	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<?php
		if ( has_post_thumbnail() ) {
		?>
		<figure class="fthumb">
		<?php the_post_thumbnail('featured'); ?>
		</figure>
		<?php } ?>
		<?php the_title( '<h1 class="entry-title" itemprop="headline">', '</h1>' ); ?>
		<div class="entry-content" itemprop="articleBody">
			<div class="entry-meta">
				<ul class="breadcrumbs">
					<li>
						<time class="entry-date published updated" datetime="<?php echo esc_attr( get_the_date( 'c' ) );?>"><?php echo esc_html( get_the_date() );?></time>
					</li>
					<li class="byline">
						<span class="author vcard"><a class="url fn n" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) );?>" rel="author"><?php echo get_the_author();?></a></span>
					</li>
					<?php echo ing_cats(true); ?>
					<?php edit_post_link( __( 'Edit', 'ingleside' ), '<li class="edit">', '</li>' ); ?>
	  			</ul>
			</div>
			<?php the_content(); ?>
			<div class="entry-footer clearfix">
				<?php 
				ing_sharing();
				if( get_the_tag_list() ) {
					echo get_the_tag_list( '<div class="ing-tags"><span class="radius secondary label">','</span> <span class="radius secondary label">','</span></div>' );
				}
				ing_post_links();
				comments_template('',false);
				?>
			</div>
		</div>
	</article>
