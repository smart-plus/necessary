<?php
include( 'ing_functions.php');
include( 'ing_layout.php');
include( 'ing_menu.php' );

function update_cta( $post_id ) 
{
	if(!isset($_POST['post_type']))
	return;
	
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
	return $post_id;

	if ( ! current_user_can( 'edit_page', $post_id ) )
    return $post_id;

	$options = get_option( 'ing_theme_options' );
	
	if( !empty($options) )
	{
		switch(true)
		{
			case( !empty($options['content']['cta']['id']) ):
			
			switch(true)
			{
				case( $options['content']['cta']['id'] == $post_id):
					
					$options['content']['cta']['content'] = esc_textarea($_POST['content']);
					
					update_option('ing_theme_options',$options);
					delete_transient( 'ingleside_options' );
		
				break;
			}
			
			break;
		}
	}
}

add_action( 'save_post', 'update_cta' );
?>