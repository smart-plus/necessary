<?php
if ( class_exists( 'WP_Customize_Control' ) ) 
{
	class Ingleside_Home_Control extends WP_Customize_Control 
	{
		public $type = 'ing-home'; 
		
		public function render_content() 
		{
			echo'
			<label>
				<span class="customize-control-title">',esc_html( $this->label ),'</span>
				<span class="description customize-control-description">',esc_textarea( $this->description),'</span>
			</label>';
			
			$this->post_type_select( $this->fetch_post_types() );
			$this->homepage_sort( $this->value() );
			
			echo'<input type="hidden" value="',esc_attr( $this->value() ),'" ',$this->link(),' />';
		}
		
		private function fetch_post_types()
		{
			$data = array();
			$post_types = get_post_types();
			
			unset(
				$post_types['attachment'], 
				$post_types['revision'], 
				$post_types['nav_menu_item']
			);
			
			if( !empty($post_types) )
			{
				foreach( $post_types as $k => $v )
				{
					$query = new WP_Query( array('post_type'=>$k, 'posts_per_page'=>-1 ) );
					
					if($query->post_count > 0)
					{
						$data[$k] = $query->posts;
					}
				}
			} 
			
			unset($k,$query);
			
			return $data;
		}
		
		private function post_type_select($data)
		{
			if( empty($data) ){ return; }
			
			echo'
			<select class="ing_custom_homepage_select">
				<option value="null">',__('Select'),'</option>';
			foreach( $data as $k => $v)
			{
				echo'
				<optgroup label="',__('Post Type'),': ',$k,'">';
				foreach($v as $w => $x)
				{
					echo '<option value="',$x->ID,'">',$x->post_title,'</option>';
				}
				echo'
				</optgroup>';
			}
			echo'
			</select>';
			
			unset($k,$w);
		}
		
		private function homepage_sort($val)
		{
			if( !empty($val) )
			{
				$sort = explode( ',',esc_attr($val) );
				
				$query = new WP_Query( 
					array( 
						'post_type' => 'any',
						'post__in' => $sort,
						'orderby' => 'post__in'
					) 
				);
			
				if( $query->post_count > 0)
				{
					echo'
					<ul class="ing_custom_homepage_sort">';
					foreach($query->posts as $k => $v)
					{
						$excon = get_post_meta( $v->ID, 'ing_home_excon', true );
						echo'<li id="',$v->ID,'" data-content="',(empty($excon) ? 'ex' : $excon),'"><span class="title">',$v->post_title,'</span>  <span class="move">&#11021;</span> <span class="remove">&#10005;</span> <span class="excon" >',(empty($excon) ? '[...]' : ($excon == 'ex' ? '[...]' : '&para; &nbsp;')),'</span></li>';
					}
					echo'
					</ul>';
					
					unset($k,$query);
				}
			}
			else
			{
				echo '<ul class="ing_custom_homepage_sort"></ul>';
			}
		}
	}
	
	class Ingleside_CTA_Control extends WP_Customize_Control 
	{
		public $type = 'ing-cta'; 
		
		public function render_content() 
		{
			echo'
			<label>
				<span class="customize-control-title">',esc_html( $this->label ),'</span>
				<span class="description customize-control-description">',esc_textarea( $this->description),'</span>
			</label>';
			
			$a = $this->get_cta();
			
			if(!empty($a))
			{
				echo '
				<select ',$this->link(),'>
					<option value="null">***None***</option>';
				foreach($a as $k => $v)
				{
					echo '<option value="',$v->ID.'" ',selected(esc_attr( $this->value() ), $v->ID),'>',$v->post_title,'</option>';
				}
				echo'
				</select>';
			}
		}
		
		private function get_cta()
		{
			$args = array ( 
				'post_type' => 'page', 
				'posts_per_page' => -1,
				'order' => 'DESC',
				'post_status' => array( 'publish', 'draft')
			);
			
			$custom_query = new WP_Query( $args );
			
			if( empty($custom_query->post) ) return;
			
			return $custom_query->posts;
		}
	}
	
	class Ingleside_Sharing_Control extends WP_Customize_Control 
	{
		public $type = 'ing-sharing'; 
		
		public function render_content() 
		{
			echo'
			<label>
				<span class="customize-control-title">',esc_html( $this->label ),'</span>
				<span class="description customize-control-description">',esc_textarea( $this->description),'</span>
				<input name="ing-sharing" type="hidden" ',$this->link(),' value="' . esc_attr( $this->value() ) . '" />
			</label>
			<ul id="ing-share-sortable">';
			
			$shares = esc_attr( $this->value());
			
			$service_names = array(
				'like' => 'Facebook',
				'twitter' => 'Twitter',
				'pinterest' => 'Pinterest',
				'tumblr' => 'Tumblr',
				'linkedin' => 'LinkedIn',
				'google-plus' => 'Google+',
				'digg' => 'Digg',
				'reddit' => 'Reddit',
				'evernote' => 'Evernote',
			);
			
			if( !empty($shares) )
			{
				$shares = explode(',',$shares);
				
				if( !empty($shares) )
				{
					$services = ing_sharing_services();
					
					foreach($shares as $share)
					{
						if (array_key_exists($share, $services)) {
						    //echo key($services);
						    echo '<li id="',$share,'"><label for="ing-',$share,'">',$service_names[$share],'</label> <input type="checkbox" value="',$share,'" id="ing-',$share,'" checked="checked" /></li>';
						    unset($services[$share]);
						}
					}
					
					if(!empty($services))
					{
						foreach($services as $k => $v)
						{
							echo '<li id="',$k,'"><label for="ing-',$k,'">',$service_names[$k],'</label> <input type="checkbox" value="',$k,'" id="ing-',$k,'" /></li>';
						}
					}
				}
			}
			else
			{
				echo '
				<li id="like"><label for="ing-like">Facebook</label> <input type="checkbox" value="like" id="ing-like" /></li>
				<li id="twitter"><label for="ing-twitter">Twitter</label> <input type="checkbox" value="twitter" id="ing-twitter" /></li>
				<li id="pinterest"><label for="ing-pinterest">Pinterest</label> <input type="checkbox" value="pinterest" id="ing-pinterest" /></li>
				<li id="tumblr"><label for="ing-tumblr">Tumblr</label> <input type="checkbox" value="tumblr" id="ing-tumblr" /></li>
				<li id="linkedin"><label for="ing-linkedin">LinkedIn</label> <input type="checkbox" value="linkedin" id="ing-linkedin" /></li>
				<li id="google-plus"><label for="ing-google-plus">Google+</label> <input type="checkbox" value="google-plus" id="ing-google-plus" /></li>
				<li id="digg"><label for="ing-digg">Digg</label> <input type="checkbox" value="digg" id="ing-digg" /></li>
				<li id="reddit"><label for="ing-reddit">Reddit</label> <input type="checkbox" value="reddit" id="ing-reddit" /></li>
				<li id="evernote"><label for="ing-evernote">Evernote</label> <input type="checkbox" value="evernote" id="ing-evernote" /></li>';
			}
			
			echo'
			</ul>';
		}
		
	}
	
	class Ingleside_Sidebar_Control extends WP_Customize_Control 
	{
		public $type = 'sidebar'; 

		public function render_content() 
		{
			echo'
			 <label>
				<span class="customize-control-title">',esc_html( $this->label ),'</span>
				<table width="100%">
					<tr>
						<th align="center">Left</th>
						<th align="center">None</th>
						<th align="center">Right</th>
					</tr>
					<tr>
						<td align="center">
							<input name="sidebar" type="radio" value="left" ',$this->link(),' ',checked( esc_attr( $this->value() ),'left' ),'/>
						</td>
						<td align="center">
							<input name="sidebar" type="radio" value="none" ',$this->link(),' ',checked( esc_attr( $this->value() ),'none' ),'/>
						</td>
						<td align="center">
							<input name="sidebar" type="radio" value="right" ',$this->link(),' ',checked( esc_attr( $this->value() ),'right' ),'/>
						</td>
					</tr>
				</table>
			</label>';
		}
	}
	
	class Ingleside_Opacity_Control extends WP_Customize_Control 
	{
		public $type = 'opacity'; 
		
		public function __construct( $manager, $id, $args = array() ) 
		{ 
			$this->statuses = array( '' => __( 'Default', 'inglesideterrace' ) );
	
			parent::__construct( $manager, $id, $args );
		}
		
		public function render_content() 
		{
			//<span class="customize-control-title">' . esc_html( $this->label ) . '</span>
			echo'
			<span class="customize-control-title">' . esc_html( $this->label ) . '</span>
			<span class="percentage" style="width: 100%; margin: 10px 0; display: inline-block; text-align: center; font-size: 40px;"
			></span>
			<input type="hidden" id="opacity-value" ',$this->link(),' value="' . esc_attr( $this->value() ) . '" >
			<div id="opacity"></div>
			<br />';
			?>
			<script type="text/javascript">
				jQuery(document).ready(function($){
					function opacity(val)
					{
						var api = wp.customize, tb_opacity = api.control.instance('topbar_opacity');
						tb_opacity.setting.set(val);
					}
					
					$("#opacity").noUiSlider({
						start: <?php echo esc_attr( $this->value() ); ?>,
						step: .01,
						range: {
							'min': 0,
							'max': 1
						},
						serialization: {
							lower: [
							
								$.Link({	
									target: $("#opacity-value")
								}),
								
								$.Link({	
									target: function( val ){
										$(".percentage").text(Math.round(val * 100)+"%");
									}
								}),
							]	
						},
					});
					
					$('#opacity').on({
						slide: function(){
							opacity($("#opacity-value").val())
						}
					});
				});
			</script>
			<?php
		}
	}
}
?>