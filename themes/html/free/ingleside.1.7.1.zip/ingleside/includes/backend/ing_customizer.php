<?php
require('ing_customizer-classes.php');

function ingleside_customize($wp_customize)
{ 
	//! Home Page
		$wp_customize->add_section( 'ing_homepage', array(
		'title'          => __( 'Home Page Controls', 'ingleside' ),
		'capability' => 'edit_theme_options',
		'priority'       => 96,
		'description'    => __( 'Ingleside Home Page Controls. Sidebars not included.', 'ingleside' ),
	) );
	
	$wp_customize->add_setting( 'ing_theme_options[home][select]', array(
		'default'        => '',
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	
	$wp_customize->add_control(
		'ing_homepage_select', 
		array(
			'label'    => __( 'Choose Home Page Style', 'ingleside' ),
			'section'  => 'ing_homepage',
			'settings' => 'ing_theme_options[home][select]',
			'type'     => 'radio',
			'choices'  => array(
				'standard'  => __('Standard', 'ingleside'),
				'ingleside' => __('Ingleside','ingleside'),
			),
			'priority' => 1,
			'active_callback' => 'is_home',
		)
	);
	
	//! - Ingleside Home Page
	
	//! --Full Width
	$wp_customize->add_setting( 'ing_theme_options[home][ingleside][fullwidth]', array(
		'default'        => '',
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	
	$wp_customize->add_control(
	    'ing_homepage_width',
	    array(
	        'type' => 'checkbox',
	        'label' => __('Fullwidth Home Page Elements?','ingleside'),
	        'section' => 'ing_homepage',
	        'settings' => 'ing_theme_options[home][ingleside][fullwidth]',
	        'priority' => 2,
	        'description' => __('This will make elements on the Ingleside Home Page full-width.', 'ingleside'),
	        'active_callback' => 'ing_active_home',
	    )
	);
	
	//! --Custom Pages
	$wp_customize->add_setting( 'ing_theme_options[home][ingleside][content]', array(
		'default'        => '',
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	
	$wp_customize->add_control( new Ingleside_Home_Control( $wp_customize, 		'ing_homepage_content', array(
		'label'   => __( 'Choose Home Page Content', 'ingleside' ),
		'section' => 'ing_homepage',
		'settings'   => 'ing_theme_options[home][ingleside][content]',
		'type'       => 'ing-home',
		'priority' => 2,
		'active_callback' => 'ing_active_home',
		'description' => __( 'Select and sort content for the home page.','ingleside' )
	) ) );

	//!	---Excon
	$wp_customize->add_setting( 'ing_theme_options[home][ingleside][excon]', array(
		'default'        => '',
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	
	$wp_customize->add_control(
	    'ing_homepage_excon',
	    array(
	        'type' => 'hidden',
	        'label' => '',
	        'section' => 'ing_homepage',
	        'settings' => 'ing_theme_options[home][ingleside][excon]',
	        'priority' => 3,
	        'active_callback' => 'ing_active_home',
	    )
	);
		
	//! --Entry Footer
	$wp_customize->add_setting( 'ing_theme_options[home][ingleside][entry_footer]', array(
		'default'        => '',
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	
	$wp_customize->add_control(
	    'ing_homepage_ef',
	    array(
	        'type' => 'checkbox',
	        'label' => __('Show Home Page Entry Footers?','ingleside'),
	        'section' => 'ing_homepage',
	        'settings' => 'ing_theme_options[home][ingleside][entry_footer]',
	        'priority' => 3,
	        'description' => __('This will show/hide entry footers on the Ingleside Home Page.', 'ingleside'),
	        'active_callback' => 'ing_active_home',
	    )
	);
	
	/* Logo */
	$wp_customize->add_section( 'ing_topbar', array(
	    'title'          => __( 'Top Bar', 'ingleside' ),
	    'capability' => 'edit_theme_options',
	    'priority'       => 95,
	    'description' => __('Adding a logo will override site title and site taglines.', 'ingleside'),
	) );
	
	$wp_customize->add_setting( 'ing_theme_options[topbar][logo]', array(
		'default'		=> '',
		'type'			=> 'option',
		'capability'	=> 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field'
	) );

	$logo = new WP_Customize_Image_Control( $wp_customize, 'ingleside_logo', array(
    	'label'    => __( 'Logo', 'ingleside' ),
		'section'  => 'ing_topbar',
		'settings' => 'ing_theme_options[topbar][logo]',
		'priority' => 1,
	) );
	
	$wp_customize->add_control($logo);
	
	$wp_customize->add_setting( 'ing_theme_options[topbar][logo_id]', array(
		'default'		=> '',
		'type'			=> 'option',
		'capability'	=> 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	
	$wp_customize->add_control(
    new WP_Customize_Control(
        $wp_customize,
        'topbar_logo_id',
        array(
            'label'          => '',
            'section'        => 'ing_topbar',
            'settings'       => 'ing_theme_options[topbar][logo_id]',
            'type'           => 'hidden',
            'priority' => 2,
          )
    ));

	$wp_customize->add_setting( 'ing_theme_options[topbar][logo_size]', array(
		'default'		=> '',
		'type'			=> 'option',
		'capability'	=> 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	
	$wp_customize->add_control(
    new WP_Customize_Control(
        $wp_customize,
        'topbar_logo_size',
        array(
            'label'          => '',
            'section'        => 'ing_topbar',
            'settings'       => 'ing_theme_options[topbar][logo_size]',
            'type'           => 'hidden',
            'priority' => 3,
          )
    ));

	$wp_customize->add_setting( 'ing_theme_options[topbar][height]', array(
		'default'		=> '',
		'type'			=> 'option',
		'capability'	=> 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	
	$wp_customize->add_control(
    new WP_Customize_Control(
        $wp_customize,
        'topbar_logo_height',
        array(
            'label'          => '',
            'section'        => 'ing_topbar',
            'settings'       => 'ing_theme_options[topbar][height]',
            'type'           => 'hidden',
            'priority' => 3,
          )
    ));
    
    
    /* Tagline */
	$wp_customize->add_setting( 'ing_theme_options[topbar][tagline]', array(
		'default'		=> 1,
		'type'			=> 'option',
		'capability'	=> 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field'
	) );

	$wp_customize->add_control(new WP_Customize_Control(
		$wp_customize,
		'topbar_tagline',
        array(
            'label'          => __('Show Tagline?','ingleside'),
            'section'        => 'ing_topbar',
            'settings'       => 'ing_theme_options[topbar][tagline]',
            'type'           => 'checkbox',
            'priority' => 5,
          )
    ));
    	
	//! -Pin Top Bar 
	$wp_customize->add_setting( 'ing_theme_options[topbar][pin]', array(
		'default'		=> 1,
		'type'			=> 'option',
		'capability'	=> 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field'
	) );

	$wp_customize->add_control(new WP_Customize_Control(
		$wp_customize,
		'topbar_pin',
        array(
            'label'          => __('Pin Top Bar?','ingleside'),
            'section'        => 'ing_topbar',
            'settings'       => 'ing_theme_options[topbar][pin]',
            'type'           => 'checkbox',
            'priority' => 6,
          )
    ));
    
    /* Follow Me */
	$wp_customize->add_setting( 'ing_theme_options[topbar][follow_enable]', array(
		'default'		=> '',
		'type'			=> 'option',
		'capability'	=> 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field'
	) );

	$wp_customize->add_control(new WP_Customize_Control($wp_customize,'topbar_follow_enable',
        array(
            'label'          => __('Enable Follow Us?','ingleside'),
            'section'        => 'ing_topbar',
            'settings'       => 'ing_theme_options[topbar][follow_enable]',
            'type'           => 'checkbox',
            'priority' => 7,
          )
    ));

	$wp_customize->add_setting( 'ing_theme_options[topbar][follow]', array(
		'default'		=> '',
		'type'			=> 'option',
		'capability'	=> 'edit_theme_options',
		'sanitize_callback'    => 'ing_sanitize_textarea',
	) );

	$wp_customize->add_control(new WP_Customize_Control($wp_customize,'topbar_follow',
        array(
            'label'          => __('Follow Us','ingleside'),
            'section'        => 'ing_topbar',
            'settings'       => 'ing_theme_options[topbar][follow]',
            'type'           => 'textarea',
            'priority' => 8,
            'description' => __('Enter your "follow" links in the following format: <strong>service|link</strong>. Here is a list of supported social media services'),
          )
    ));
   
    
    
/*
 * 
 ******************************* Content Settings *******************
 *
 */
	
	$wp_customize->add_section( 'ing_content', array(
		'title'          => __( 'The Content', 'ingleside' ),
		'capability' => 'edit_theme_options',
		'priority'       => 96,
		'description'    => __( 'Content settings.', 'ingleside' ),
	) );

    $wp_customize->add_setting('ing_theme_options[content][cta][id]', array(
        'capability'     => 'edit_theme_options',
        'type'           => 'option',
        'sanitize_callback' => 'sanitize_text_field'
    ));
 
	$wp_customize->add_control( new Ingleside_CTA_Control( $wp_customize, 		'ing_content_cta', array(
		'label'   => __( 'Select Call to Action', 'ingleside' ),
		'section' => 'ing_content',
		'settings'   => 'ing_theme_options[content][cta][id]',
		'type'       => 'ing-cta',
		'priority' => 2,
		'active_callback' => 'is_front_page',
		'description' => __( 'Select a page that contains your Call to action/hero header.', 'ingleside' )
	) ) );
	
		
	$wp_customize->add_setting( 'ing_theme_options[content][sharing]', array(
		'default'        => 1,
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );

	$wp_customize->add_control(
	    'ing_content_sharing',
	    array(
	        'type' => 'checkbox',
	        'label' => __('Enable Sharing?','ingleside'),
	        'section' => 'ing_content',
	        'settings' => 'ing_theme_options[content][sharing]',
	        'priority' => 3,
	        'active_callback' => 'ing_single'
	    )
	);

	$wp_customize->add_setting( 'ing_theme_options[content][sharing_options]', array(
		'default'        => 'like,twitter,pinterest,tumblr,linkedin,google-plus',
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );

	$wp_customize->add_control( new Ingleside_Sharing_Control( $wp_customize, 		'ing_content_sharing_options', array(
		'label'   => __( 'Sharing Services', 'ingleside' ),
		'section' => 'ing_content',
		'settings'   => 'ing_theme_options[content][sharing_options]',
		'type'       => 'ing-sharing',
		'priority' => 4,
		'active_callback' => 'ing_single',
		'description' => __( 'Select up to 6', 'ingleside' )
	) ) );

	
	$wp_customize->add_setting( 'ing_theme_options[content][prevnext]', array(
		'default'        => '',
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );

	$wp_customize->add_control(
	    'ing_content_prevnext',
	    array(
	        'type' => 'checkbox',
	        'label' => __('Enable Previous/Next?','ingleside'),
	        'section' => 'ing_content',
	        'settings' => 'ing_theme_options[content][prevnext]',
	        'priority' => 5,
	        'active_callback' => 'ing_single'
	    )
	);
	
	/*
	 * !Sidebar 
	 */
	 	
	$wp_customize->add_section( 'ing_sidebar', array(
		'title'          => __( 'The Sidebar', 'ingleside' ),
		'capability' => 'edit_theme_options',
		'priority'       => 97,
		'description'    => __( 'Sidebar settings.', 'ingleside' ),
		'active_callback' => 'ing_active_sidebar'
	) );
	
	/* Dual Control */
	$wp_customize->add_setting( 'ing_theme_options[sidebar][location]', array(
		'default'        => '',
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );

	$wp_customize->add_control( new Ingleside_Sidebar_Control( $wp_customize, 		'sidebar_location', array(
		'label'   => __( 'Sidebar Location', 'ingleside' ),
		'section' => 'ing_sidebar',
		'settings'   => 'ing_theme_options[sidebar][location]',
		'type'       => 'sidebar',
		'priority' => 3,
	) ) );
	
	//Pin Sidebar
	$wp_customize->add_setting( 'ing_theme_options[sidebar][pin]', array(
		'default'        => '',
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );

	$wp_customize->add_control(
	    'sidebar_pin',
	    array(
	        'type' => 'checkbox',
	        'label' => __('Pin Sidebar?','ingleside'),
	        'section' => 'ing_sidebar',
	        'settings' => 'ing_theme_options[sidebar][pin]',
	        'priority' => 2,
	        'active_callback' => 'ing_cta_active',
	    )
	);
/*
 * 
 ******************************* !Color Panel *******************
 *
 */
	
	$wp_customize->remove_section('colors');
	
	$wp_customize->add_panel( 'ing_colors', array(
	    'priority'       => 94,
	    'capability'     => 'edit_theme_options',
	    'theme_supports' => '',
	    'title'          => __( 'Palette Unlimted', 'ingleside' ),
	    'description'    => '',
	) );
	
	$wp_customize->add_section( 'ing_background', array(
	    'priority'       => 1,
	    'capability'     => 'edit_theme_options',
	    'theme_supports' => '',
	    'title'          => __( 'Background', 'ingleside' ),
	    'description'    => '',
	    'panel'  => 'ing_colors',
	) );
	
	$wp_customize->add_setting( 'background_color', array(
		'default'        => get_theme_support( 'custom-background', 'default-color' ),
		'theme_supports' => 'custom-background',

		'sanitize_callback'    => 'sanitize_hex_color_no_hash',
		'sanitize_js_callback' => 'maybe_hash_hex_color',
	) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'background_color', array(
		'label'   => __( 'Background Color', 'ingleside' ),
		'section' => 'ing_background',
	) ) );
		
////////////
/////!Top bar
////////////

    $wp_customize->add_section( 'ing_topbar_color', array(
	    'priority'       => 2,
	    'capability'     => 'edit_theme_options',
	    'theme_supports' => '',
	    'title'          => __( 'Top Bar Color', 'ingleside' ),
	    'description'    => '',
	    'panel'  => 'ing_colors',
	) );
	
	ing_color_palette($wp_customize,'topbar','Top Bar Color','[topbar]','ing_topbar_color','#ffffff');
		/* Opacity */
	$wp_customize->add_setting( 'ing_theme_options[palette][topbar][opacity]', array(
		'default'		=> 0.8,
		'type'			=> 'option',
		'capability'	=> 'edit_theme_options',
		'transport' => 'postMessage',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	
	$wp_customize->add_control( new Ingleside_Opacity_Control( $wp_customize, 		'topbar_opacity', array(
		'label'   => __( 'Top Bar Opacity', 'ingleside' ),
		'section' => 'ing_topbar_color',
		'settings'   => 'ing_theme_options[palette][topbar][opacity]',
		'type'       => 'opacity',
		'priority' => 4,
	) ) );
	
	$wp_customize->get_setting('ing_theme_options[palette][topbar][opacity]')->transport='postMessage';
	
	
////////////////////
/////!Standard Links
///////////////////
	$wp_customize->add_section( 'ing_link_color', array(
	    'priority'       => 2,
	    'capability'     => 'edit_theme_options',
	    'theme_supports' => '',
	    'title'          => __('Standard Link Color', 'ingleside' ),
	    'description'    => '',
	    'panel'  => 'ing_colors',
	) );

	ing_color_palette($wp_customize,'links','Standard Link Color','[links]','ing_link_color','#000000');

/////////////////
/////!The Content
////////////////
    $wp_customize->add_section( 'ing_content_color', array(
	    'priority'       => 3,
	    'capability'     => 'edit_theme_options',
	    'theme_supports' => '',
	    'title'          => __( 'Content Colors', 'ingleside' ),
	    'description'    => '',
	    'panel'  => 'ing_colors',
	) );

	ing_color_palette($wp_customize,'content_title','Title Color','[content][title]','ing_content_color','#666666');
	
	ing_color_palette($wp_customize,'content_header','Heading Color','[content][header]','ing_content_color','#222',2);
		
	ing_color_palette($wp_customize,'content_paragraph','Paragraph Color','[content][paragraph]','ing_content_color','#666',3);
	
	ing_color_palette($wp_customize,'content_breadcrumbs','Breadcrumbs & Tags Color','[content][breadcrumbs]','ing_content_color','#f4f4f4',4,'ing_single');
	
	ing_color_palette($wp_customize,'content_sharing','Sharing Color','[content][sharing]','ing_content_color','#fff',5,'ing_single');
	
	ing_color_palette($wp_customize,'content_columns','Column Color','[content][columns]','ing_content_color','#fff',6,'ing_single');
	
/////////////////
/////!The Comments
////////////////
    $wp_customize->add_section( 'ing_comment_color', array(
	    'priority'       => 4,
	    'capability'     => 'edit_theme_options',
	    'theme_supports' => '',
	    'title'          => __( 'Comment Colors', 'ingleside' ),
	    'description'    => '',
	    'panel'  => 'ing_colors',
	) );
	
	ing_color_palette($wp_customize,'comments','Comments Color','[comments]','ing_comment_color','#f2f2f2',1,'ing_single');
	

//////The Sidebar
    $wp_customize->add_section( 'ing_sidebar_color', array(
	    'priority'       => 5,
	    'capability'     => 'edit_theme_options',
	    'theme_supports' => '',
	    'title'          => __( 'Sidebar Color', 'ingleside' ),
	    'description'    => '',
	    'panel'  => 'ing_colors',
	) );
	
	ing_color_palette($wp_customize,'sidebar','Sidebar Color','[sidebar]','ing_sidebar_color','#ffffff');
////////////////

//////////Buttons
$wp_customize->add_section( 'ing_buttons', array(
    'priority'       => 6,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => __( 'Button Colors', 'ingleside' ),
    'description'    => '',
    'panel'  => 'ing_colors',
) );
	
$buttons = array(
	'primary' => '#008cba',
	'secondary' => '#dadada',
	'success' => '#43ac6a',
	'alert' => '#f04124',
);

$i = 0;
foreach($buttons as $k => $v)
{
	++$i;
	ing_color_palette($wp_customize,'buttons_'.$k,ucfirst($k).' Button Color','[buttons]['.$k.']','ing_buttons',$v, $i);
}

	//! -- Ghost Buttons 
	$wp_customize->add_setting( 'ing_theme_options[palette][buttons][ghost]', array(
		'default'        => '',
		'capability'     => 'edit_theme_options',
		'type'           => 'option',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	
	$wp_customize->add_control(
	    'ing_ghost_protocol',
	    array(
	        'type' => 'checkbox',
	        'label' => __('Ghost Protocol','ingleside'),
	        'section' => 'ing_buttons',
	        'settings' => 'ing_theme_options[palette][buttons][ghost]',
	        'priority' => 5,
	        'description' => __('This will apply a "ghost style" to the buttons.', 'ingleside'),
	    )
	);

	/*
	 * Footer 
	 */
	 
	$wp_customize->add_section( 'ing_footer_color', array(
	    'priority'       => 7,
	    'capability'     => 'edit_theme_options',
	    'theme_supports' => '',
	    'title'          => __( 'Footer Color', 'ingleside' ),
	    'description'    => '',
	    'panel'  => 'ing_colors',
	) );
	
	ing_color_palette($wp_customize,'footer','Footer Color','[footer]','ing_footer_color','#ffffff');
	
	$wp_customize->add_section( 'ing_footer', array(
	    'title'          => __( 'Footer', 'ingleside' ),
	    'capability' => 'edit_theme_options',
	    'priority'       => 98,
	    'description' => __('Footer settings.', 'ingleside'),
	) );
	
	$wp_customize->get_setting( 'blogdescription'   )->transport = 'postMessage';
    
	if ( $wp_customize->is_preview() && ! is_admin() ) {
	    add_action('wp_enqueue_scripts','preview_script');
	}
}

function preview_script()
{
	wp_enqueue_script( 'ingleside-customizer-preview',get_template_directory_uri().'/includes/backend/js/ingleside-customizer-preview.min.js', array( 'jquery'), '', true);
}

function logo_tab()
{
	echo'<a class="choose-from-library-link button" data-controller="logo-upload">'.__( 'Open Library' ).'</a>';
}

function ingleside_customizer_css()
{
	wp_enqueue_style( 'nouislider-css', get_template_directory_uri().'/includes/backend/css/jquery.nouislider.css' );
	
	wp_enqueue_style( 'ingleside-customizer-css', get_template_directory_uri().'/css/ingleside-customizer.css' );
}

function ingleside_customizer_js() 
{
	wp_enqueue_media();
	
	wp_enqueue_script( 'ingleside-customizerjs',get_template_directory_uri().'/includes/backend/js/ingleside-customizer.min.js', array( 'jquery'), '', true);
	
	wp_enqueue_script('jquery-ui-sortable');
	
	wp_localize_script( 'ingleside-customizerjs', 'icTools', 
		array('template_url' => get_template_directory_uri(), 
		'ajaxurl' => admin_url('admin-ajax.php'), 
		'sec' => wp_create_nonce( 'lakeview'),
		'url_nonce' => wp_nonce_url('customize.php','ingleside-customizer'),
		) 
	);
	
	wp_enqueue_script( 'nouislider-js',get_template_directory_uri().'/includes/backend/js/jquery.nouislider.min.js', array( 'jquery'), '', true);
	wp_enqueue_script( 'tinycolor',get_template_directory_uri().'/includes/backend/js/tinycolor.min.js', array( 'jquery'), '1.0', true);
	
}

add_action('customize_register', 'ingleside_customize');
add_action('customize_controls_print_styles', 'ingleside_customizer_css', 30);
add_action( 'customize_controls_enqueue_scripts', 'ingleside_customizer_js', 30);
add_action('customize_save_after','ing_crunch_follow');
add_action('customize_save_after','refresh_ingleside_options');
add_action('customize_save_after','ing_save_cta');
add_action('customize_save_after','ing_logo_size');
add_action('customize_save_after','ing_save_excon');

function ing_save_excon()
{
	$ing_options = get_option('ing_theme_options');
	
	if( empty($ing_options) ){ return; }

	if( !empty($ing_options['home']['ingleside']['excon']) )
	{
		$a = explode(",",$ing_options['home']['ingleside']['excon']);
		
		if( !empty($a) )
		{
			foreach($a as $b)
			{
				$b = explode("-", $b);			
				update_post_meta($b[0], 'ing_home_excon', $b[1]);
			}
		}
	}
	
}

function ing_logo_size()
{
	$ing_options = get_option('ing_theme_options');
	
	if( !empty( $ing_options['topbar']['logo'] ) )
	{
		$ing_options['topbar']['logo_size'] = ing_get_logo_size($ing_options['topbar']['logo']);
	}
	else
	{
		$ing_options['topbar']['logo_size'] = '';
	}
	
	update_option( 'ing_theme_options', $ing_options );
}

function ing_save_cta()
{
	$ing_options = get_option('ing_theme_options');
	
	if( !empty($ing_options) )
	{
		if(!empty($ing_options['content']['cta']['id']))
		{
			$args = array(
				'page_id' => (int)$ing_options['content']['cta']['id'],
			);
			
			$custom_query = new WP_Query( $args );
			
			if(!empty($custom_query->post)){
				$ing_options['content']['cta']['content'] = esc_html($custom_query->post->post_content);
				
			}
		}
	}
	
	update_option( 'ing_theme_options', $ing_options );
}

function refresh_ingleside_options()
{
	delete_transient( 'ingleside_options' );
}

function ing_crunch_follow()
{
	$ing_options = get_option('ing_theme_options');
	
	if(empty($ing_options['topbar']['follow'])) return;
	
	$follow_me = array();
	$follow_us = preg_split('/\r\n|\r|\n/',$ing_options['topbar']['follow']);
	
	foreach($follow_us as $follow)
	{
		if(!empty($follow))
		{
			$us = explode('|',$follow);
			if(!empty($us[0]) && !empty($us[1])){
				$follow_me[sanitize_title(trim($us[0]))] = esc_url(trim($us[1]));
			}
		}
	}
	
	$ing_options['topbar']['follow_us'] = $follow_me;
	
	update_option('ing_theme_options',$ing_options);
}

function ing_color_palette($wp_customize,$prefix,$name,$keys,$section,$default = false,$priority = false, $active = '')
{
	$colors = array('background_color','darken','contrast','complement','bw');
	$i = 0;
	
	foreach($colors as $color)
	{
		$i++;
		$wp_customize->add_setting( 'ing_theme_options[palette]'.$keys.'['.$color.']', array(
			'default'		=> ($color == 'background_color' ? $default : ''),
			'type'			=> 'option',
			'capability'	=> 'edit_theme_options',
			'transport' => 'postMessage',
			'sanitize_callback' => 'sanitize_text_field'
		) );
		
		if($color != 'background_color')
		{
			$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 		$prefix.'_'.$color, array(
				'label'   => '',
				'section' => $section,
				'settings'   => 'ing_theme_options[palette]'.$keys.'['.$color.']',
				'type'       => 'hidden',
				'active_callback' => $active,
			) ) );
		}
		else
		{
			$n = sprintf(__('%s', 'ingleside'), $name);
			$wp_customize->add_control( new WP_Customize_Color_Control( 
				$wp_customize, 
				$prefix.'_'.$color, 
				array(
					'label'      => $n,
					'section'    => $section,
					'settings'   => 'ing_theme_options[palette]'.$keys.'[background_color]',
					'priority'	=> $priority !== '' ? $priority : 1,
					'active_callback' => $active,
				) ) 
			);
		}
		
		$wp_customize->get_setting('ing_theme_options[palette]'.$keys.'['.$color.']')->transport='postMessage';
	}
	
	return $wp_customize;
}

//!Actives
function ing_active_sidebar()
{
	$ing_options = get_option('ing_theme_options');
	
	if( !empty($ing_options['home']['select']) )
	{
		if( is_home() && 'ingleside' == $ing_options['home']['select']){
			return 0;
		}else{
			return 1;
		}
	}
	else
	{
		return 1;
	}
}


function ing_active_home()
{
	$ing_options = get_option('ing_theme_options');
	
	if( empty($ing_options['home']) )
	{
		return 0;
	}
	else
	{
		if( is_home() && 'ingleside' == $ing_options['home']['select']){
			return 1;
		}else{
			return 0;
		}
	}
}


function ing_cta_active()
{
	$ing_options = get_option('ing_theme_options');
	
	if(ing_cta($ing_options) != '' && is_front_page() && !is_singular()){
		return 0;
	}else{
		return 1;
	}
}

function ing_single()
{
	if(is_singular()){
		return 1;
	}else{
		return 0;
	}
}

function ing_is_archive()
{
	if(is_archive() || is_front_page()){
		return 1;
	}else{
		return 0;
	}
}

function ing_is_int($input)
{
	return (int)$input ? $input : null;
}

function ing_sanitize_textarea($input)
{
	return strip_tags(esc_attr($input));
}
?>