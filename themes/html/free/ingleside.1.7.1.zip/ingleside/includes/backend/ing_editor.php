<?php

function ing_editor_popups_styles(){
	
	echo '
	<style type="text/css">
	
		#ingbuttons label,
		#ingbuttons input,
		#ingcolumns label
		{
			line-height: 28px;	
		}
		
		#ingbutton-int_url{
			width: 179px;
		}
		
		.ing_buttons label,
		.ing_buttons #ing-insert-buttons,
		.ing_columns #ing-insert-columns{
			display: block;
		}
		
		.ing_buttons input[type=text],
		.ing_buttons #ing-insert-buttons,
		.ing_columns #ing-insert-columns{
			width: 90%;
		}
		
		i.mce-ico.mce-i-ingtools:before{
			content: url(',get_template_directory_uri(),'/includes/backend/css/sundial.svg) no-repeat;
		}
	</style>';

}

add_action('admin_print_styles', 'ing_editor_popups_styles');

function ing_editor_colors()
{
	$ing_options = get_option('ing_theme_options');
	
	if( empty($ing_options) ){return;}
?>
<script type="text/javascript">
jQuery(window).load(function($) {
	var tinyMCEhead = jQuery("iframe#content_ifr:visible").contents().find("head");
	<?php 
	if(!empty($ing_options['palette']['content']['columns']['background_color'])){?>
	tinyMCEhead.append('<style type="text/css">.ingcols > li{background-color:<?php echo $ing_options['palette']['content']['columns']['background_color'];?>;}.ingcols > li h1,.ingcols > li h2,.ingcols > li h3,.ingcols > li h4,.ingcols > li h5,.ingcols > li h1 a,.ingcols > li h2 a,.ingcols > li h3 a,.ingcols > li h4 a,.ingcols > li h5 a,.ingcols > li,.ingcols > li p{color:<?php echo $ing_options['palette']['content']['columns']['bw'];?>;}.ingcols > li h1 a:hover,.ingcols > li h2 a:hover,.ingcols > li h3 a:hover,.ingcols > li h4 a:hover,.ingcols > li h5 a:hover{color: rgb(<?php echo $ing_options['palette']['content']['columns']['complement'];?>);}</style>');
	<?php } ?>
	<?php if(!empty($ing_options['palette']['content']['header']['background_color']) && !empty($ing_options['palette']['content']['paragraph']['background_color'])){?>
	tinyMCEhead.append('<style type="text/css">h1,h2,h3,h4,h5,h6,h1 a,h2 a,h3 a,h4 a,h5 a,h6 a {color:<?php echo $ing_options['palette']['content']['header']['background_color'];?>;} h1 a:hover,h2 a:hover,h3 a:hover,h4 a:hover,h5 a:hover,h6 a:hover {color: rgb(<?php echo $ing_options['palette']['content']['header']['complement'];?>);} p{color:<?php echo $ing_options['palette']['content']['paragraph']['background_color'] ;?>;}</style>');
	<?php }?>
	<?php if(!empty($ing_options['palette']['links']['background_color'])){?>
	tinyMCEhead.append('<style type="text/css">a {color:<?php echo $ing_options['palette']['links']['background_color']; ?>;} a:hover {color:<?php echo $ing_options['palette']['links']['complement']; ?>;}</style>');
	<?php } ?>
});
</script>
<?php
}

add_action('admin_footer', 'ing_editor_colors');

function add_ingleside_button() {
   // Don't bother doing this stuff if the current user lacks permissions
   if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') )
     return;
 
   // Add only in Rich Editor mode
	if ( get_user_option('rich_editing') == 'true') 
	{
		add_filter("mce_external_plugins", "add_ingleside_tinymce_plugin");
		add_filter('mce_buttons', 'register_ingelside_button');
	 
		wp_enqueue_script( 'jquery' );
		
		$e = new editPopup();
		$needs = array(
			'int_links' => $e->internal_links(),
			'buttons' => $e->button_styles(),
		);
		
		wp_localize_script( 'jquery', 'ingTools', array('template_url' => get_template_directory_uri().'/includes/assets/', 'needs' => $needs) );	
	}
}
 
function register_ingelside_button($buttons) {
   array_push($buttons, "|", "ingtools");
   return $buttons;
}
 
// Load the TinyMCE plugin : editor_plugin.js (wp2.5)
function add_ingleside_tinymce_plugin($plugin_array) {
   $plugin_array['ingtools'] = get_template_directory_uri().'/includes/backend/js/editor_plugin.min.js';
   return $plugin_array;
}
 
function my_refresh_mce($ver) {
  $ver += 3;
  return $ver;
}

// init process for button control
add_filter( 'tiny_mce_version', 'my_refresh_mce');
add_action('init', 'add_ingleside_button');

class editPopup
{
	public function button_styles()
	{
		$classes = array(
			'standard' => array(
				'regular' => 'button',
				'small' => 'button small',
				'tiny' => 'button tiny',
			),
			'secondary' => array(
				'regular' => 'button secondary',
				'small' => 'button secondary small',
				'tiny' => 'button secondary tiny',
			),
			'alert' => array(
				'regular' => 'button alert',
				'small' => 'button alert small',
				'tiny' => 'button alert tiny',
			),
			'success' => array(
				'regular' => 'button success',
				'small' => 'button small success',
				'tiny' => 'button tiny success',
			),
		);
		
		if(!empty($classes))
		{
			return $classes;
		}
	}
	
	private function post_types()
	{
		$types = get_post_types();
		unset($types['attachment'],$types['revision'],$types['nav_menu_item']);
		
		$data = array();
		
		if(!empty($types))
		{
			foreach($types as $type)
			{
				$data[] = $type;
			}
		}
		
		return $data;
	}
	
	public function internal_links()
	{
		$types = $this->post_types();
		$data = array();
		$args = array(
			'post_type' => $types,
			'posts_per_page' => -1,
		);
		
		$custom_query = new WP_Query($args);
		
		if ( $custom_query->have_posts() )
		{
		    while ( $custom_query->have_posts() )
			{
		        $custom_query->the_post();
				$title = get_the_title();
				$data[$title][] = get_permalink();
		    }
			wp_reset_postdata();
		}
		
		wp_reset_query();
		
		return $data;
	}
}
?>