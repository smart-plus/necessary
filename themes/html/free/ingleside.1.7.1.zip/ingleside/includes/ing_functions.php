<?php
function ing_crunch_button_colors($ing_options, $button = null, $attr = array())
{
	$processed_colors = array();
	$button = !empty($button) ? $button : 'primary';
	$defaults = array(
		'primary' => array(
			'color' => 'white',
			'background' => '#008CBA',
			'border' => '#007095',
		),
		'secondary' => array(
			'color' => '#333333',
			'background' => '#e7e7e7',
			'border' => '#b9b9b9',
		),
		'success' => array(
			'background' => '#43AC6A',
			'border' => '#368a55',
			'color' => '#FFFFFF',
		),
		'alert' => array(
			'background' => '#f04124',
			'border' => '#cf2a0e',
			'color' => '#FFFFFF',
		),
	);
		
	if(!empty($ing_options['palette']['buttons']['ghost']))
	{
		$processed_colors['background'] = 'transparent';
		$processed_colors['border-width'] = '3px';
		
		if(!empty($ing_options['palette']['buttons'][$button]))
		{
			$processed_colors['darken'] = !empty($ing_options['palette']['buttons'][$button]['darken']) ? 'rgb('.$ing_options['palette']['buttons'][$button]['darken'].')' : $defaults[$button]['border'];
			
			$processed_colors['bw'] = !empty($ing_options['palette']['buttons'][$button]['darken']) ? 'rgb('.$ing_options['palette']['buttons'][$button]['darken'].')' : $defaults[$button]['border'];
			
			$processed_colors['bw-hover'] = !empty($ing_options['palette']['buttons'][$button]['bw']) ? $ing_options['palette']['buttons'][$button]['bw'] : $defaults[$button]['color'];
			
			$processed_colors['background-hover'] = !empty($ing_options['palette']['buttons'][$button]['contrast']) ? 'rgb('.$ing_options['palette']['buttons'][$button]['contrast'].')' : $defaults[$button]['background'];
		}
		else
		{
			$processed_colors['darken'] = !empty($ing_options['palette']['buttons'][$button]['darken']) ?: $defaults[$button]['border'];
			
			$processed_colors['bw'] = !empty($ing_options['palette']['buttons'][$button]['bw']) ?: $defaults[$button]['border'];
			
			$processed_colors['bw-hover'] = !empty($ing_options['palette']['buttons'][$button]['bw']) ?: $defaults[$button]['color'];
			
			$processed_colors['background-hover'] = !empty($ing_options['palette']['buttons'][$button]['darken']) ?: $defaults[$button]['border'];
			
		}
	}
	else
	{
		$processed_colors['border-width'] = '0px';
		
		if(!empty($ing_options['palette']['buttons'][$button]))
		{
			$processed_colors['darken'] = !empty($ing_options['palette']['buttons'][$button]['darken']) ? 'rgb('.$ing_options['palette']['buttons'][$button]['darken'].')' : $defaults[$button]['border'];
			
			$processed_colors['bw'] = !empty($ing_options['palette']['buttons'][$button]['bw']) ? $ing_options['palette']['buttons'][$button]['bw'] : $defaults[$button]['color'];
			
			$processed_colors['bw-hover'] = !empty($ing_options['palette']['buttons'][$button]['bw']) ? $ing_options['palette']['buttons'][$button]['bw'] : $defaults[$button]['color'];
			
			$processed_colors['background'] = !empty($ing_options['palette']['buttons'][$button]['background_color']) ? $ing_options['palette']['buttons'][$button]['background_color'] : $defaults[$button]['background'];
			
			$processed_colors['background-hover'] = !empty($ing_options['palette']['buttons'][$button]['contrast']) ? 'rgb('.$ing_options['palette']['buttons'][$button]['contrast'].')' : $defaults[$button]['border'];		
		}
		else
		{
			$processed_colors['background'] = !empty($ing_options['palette']['buttons'][$button]['background_color']) ?: $defaults[$button]['background'];
			
			$processed_colors['background-hover'] = !empty($ing_options['palette']['buttons'][$button]['darken']) ?: $defaults[$button]['border'];
			
			$processed_colors['darken'] = !empty($ing_options['palette']['buttons'][$button]['darken']) ?: $defaults[$button]['border'];
			
			$processed_colors['bw'] = !empty($ing_options['palette']['buttons'][$button]['bw']) ?: $defaults[$button]['color'];
			
			$processed_colors['bw-hover'] = !empty($ing_options['palette']['buttons'][$button]['bw']) ?: $defaults[$button]['color'];
		}
	}

	return $processed_colors;
}

function ing_update_excon($ing_options)
{
	if( empty($ing_options) ){ return; }
	
	if(is_customize_preview())
	{
		if( !empty($ing_options['home']['ingleside']['excon']) )
		{
			$a = explode(",",$ing_options['home']['ingleside']['excon']);
			
			if( !empty($a) )
			{
				foreach($a as $b)
				{
					$b = explode("-", $b);			
					update_post_meta($b[0], 'ing_home_temp_excon', $b[1]);
				}
			}
		}
	}
}

function ing_get_logo_size($logo)
{
	if( empty($logo) ){return;}
	
	$check = wp_check_filetype( esc_attr($logo) );
	$size = array();
	
	if($check['type'] == 'image/svg+xml'){
		$xml = wp_remote_get($logo);
		$xmlget = simplexml_load_string($xml['body']);
		$xmlattributes = $xmlget->attributes();
		$size['width'] = (string)$xmlattributes->width;
		$size['height'] = (string)$xmlattributes->height;
	}else{
		$size = wp_get_attachment_metadata( attachment_url_to_postid($logo) );
	}
	
	return $size;
}

add_filter("post_gallery", "gallery_test",10,2);

function gallery_test( $output, $attr )
{
    if ( isset( $attr['orderby'] ) ) {
        $attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
        if ( !$attr['orderby'] ){
            unset( $attr['orderby'] );
        }
    }
    
	$attachments = array();
	$output = null;
	
	if( !empty($attr) )
	{
		if( !empty($attr['ids']) )
		{			
			$attachments = get_posts( array('include' => esc_attr( $attr['ids'] ), 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image') );
		}
		
		if( !empty($attachments) )
		{
			$some_columns = !isset($attr['columns']) ? '3' : $attr['columns'];
			
			$output .= '
			<ul class="ing-gallery small-block-grid-1 medium-block-grid-'.$some_columns.' large-block-grid-'.$some_columns.'">';
			foreach( $attachments as $k => $v )
			{
				$output .= '
				<li>
					<figure>';
					if( !isset($attr['link']) ){
						$output .= '<a href="'.home_url('/?attachment_id='.$v->ID).'">'.wp_get_attachment_image( $v->ID).'</a>';
					}elseif( isset($attr['link']) && 'file' == $attr['link'] ){
						$output .= '<a href="'.$v->guid.'">'.wp_get_attachment_image( $v->ID ).'</a>';
					}elseif( isset($attr['link']) && 'none' == $attr['link'] ){
						$output .= wp_get_attachment_image( $v->ID );
					}
					if( !empty($v->post_excerpt) ){
						$output .= '<figcaption>'.esc_attr( $v->post_excerpt ).'</figcaption>';
					}
					$output .= '
					</figure>
				</li>';
			}
			$output .= '
			</ul>';
		}
	}
	
	return $output;
}

function ing_follow($mobile = false)
{
	$ing_options = ingleside_options();
		
	if(is_customize_preview())
	{
		if( !empty($ing_options['topbar']['follow_enable']) && isset($ing_options['topbar']['follow']) )
		{
			$follow_us = preg_split('/\r\n|\r|\n/',$ing_options['topbar']['follow']);
			
			echo '
			<div class="ing-follow hide-for-small clearfix">
				<ul class="inline-list right">';
				
			foreach($follow_us as $follow)
			{
				if(!empty($follow))
				{
					$us = explode('|',$follow);
					if( !empty($us[0]) && !empty($us[1]) ){
						echo '<li><a href="',esc_url( trim($us[1] )),'" target="_blank" rel="nofollow"><i class="fi-social-',sanitize_title( trim($us[0]) ),'"></i></a></li>';
					}
				}
			}
			
			unset($follow);
			echo'
				</ul>
			</div>';
		}
	}
	else
	{
		if(	!empty($ing_options['topbar']['follow_enable']) && !empty($ing_options['topbar']['follow_us']) )
		{
			if(	$mobile	)
			{
				echo'<li class="has-form show-for-small mobile-follow">';
				foreach( $ing_options['topbar']['follow_us'] as $k => $v )
				{
					echo '<a href="',esc_url($v),'" target="_blank" rel="nofollow"><i class="fi-social-',$k,'"></i></a>';
				}
				echo '</li>';
				
				unset($k);
			}
			else
			{
				echo '
				<div class="ing-follow hide-for-small clearfix">
					<ul class="inline-list right">';
					foreach( $ing_options['topbar']['follow_us'] as $k => $v )
					{
						echo '<li><a href="',esc_url($v),'" target="_blank" rel="nofollow"><i class="fi-social-',$k,'"></i></a></li>';
					}
					echo'
					</ul>
				</div>';
				
				unset($k);
			}
		}
	}
}

function ing_post_links()
{
	
	$ing_options = ingleside_options();
	if( isset($ing_options['content']['prevnext']) && 1 == (int)$ing_options['content']['prevnext'] ){
		echo '
		<ul class="pn-links small-block-grid-2 medium-block-grid-2 large-block-grid-2">
			<li>',previous_post_link(),'</li>
			<li>',next_post_link(),'</li>
		</ul>';
	}
}

function ing_sharing_services()
{
	global $post;
	
	$services = array(
		'like' => 'http://www.facebook.com/share.php?u='.urlencode(get_permalink()).'&amp;title='.urlencode(single_post_title('',false)),
		'twitter' => 'http://twitter.com/home?status='.urlencode(single_post_title('',false)).'+'.urlencode(get_permalink()),
		'pinterest' => 'http://pinterest.com/pin/create/button/?url='.urlencode(get_permalink()).'&amp;media='.urlencode(wp_get_attachment_url( get_post_thumbnail_id($post->ID,'medium') )).'&amp;description='.urlencode(strip_tags($post->post_excerpt)),
		'tumblr' => 'http://www.tumblr.com/share?v=3&amp;u='.urlencode(get_permalink()).'&amp;t='.urlencode(single_post_title('',false)),
		'linkedin' => 'http://www.linkedin.com/shareArticle?mini=true&amp;url='.urlencode(get_permalink()).'&amp;title='.urlencode(single_post_title('',false)).'&amp;source='.urlencode(get_bloginfo('name')),
		'google-plus' => 'https://plus.google.com/share?url='.urlencode(get_permalink()),
		'digg' => 'http://www.digg.com/submit?phase=2&url='.urlencode(get_permalink()).'&amp;title='.urlencode(single_post_title('',false)),
		'reddit' => 'http://www.reddit.com/submit?url='.urlencode(get_permalink()).'&amp;title='.urlencode(single_post_title('',false)),
		'evernote' => 'http://www.evernote.com/clip.action?url='.urlencode(get_permalink()).'&amp;title='.urlencode(single_post_title('',false)),
	);
	
	return $services;
}

function ing_sharing()
{
	global $post;
	
	$ing_options = ingleside_options();
	$output = '';

	if(!isset($ing_options['content']['sharing']) || 1 == (int)$ing_options['content']['sharing'])
	{
		$count = array(
			1 => 'one',
			2 => 'two',
			3 => 'three',
			4 => 'four',
			5 => 'five',
			6 => 'six',
			7 => 'six',
			8 => 'six',
			9 => 'six',
		);
		
		$services = ing_sharing_services();
		
		if(!isset($ing_options['content']['sharing_options']) || empty($ing_options['content']['sharing_options']))
		{
			$seven = $count[count($services)];
			echo '<div class="icon-bar '.$seven.'-up">';
			
			$i = 0;
			foreach($services as $share => $link)
			{
				$i++;
				if($share == 'like'){
					echo '<a href="',$link,'" target="_blank" rel="nofollow" class="item"><i class="fi-',$share,'"></i></a>';
				}else{
					echo '<a href="',$link,'" target="_blank" rel="nofollow" class="item"><i class="fi-social-',$share,'"></i></a>';
				}
				
				if($i > 5){
					break;
				}
			}
			
			echo '</div>';
		}
		else
		{
			$sharing = explode( ',',$ing_options['content']['sharing_options'] );
			
			if(!empty($sharing))
			{
				$seven = $count[count($sharing)];
				echo'<div class="icon-bar '.$seven.'-up">';
				
				$i = 0;
				foreach($sharing as $share)
				{
					$i++;
					if($share == 'like'){
						echo '<a href="',$services[$share],'" target="_blank" rel="nofollow" class="item"><i class="fi-'.$share.'"></i></a>';
					}else{
						echo '<a href="',$services[$share],'" target="_blank" rel="nofollow" class="item"><i class="fi-social-',$share,'"></i></a>';
					}
					
					if($i > 5){
						break;
					}
				}
				
				echo '</div>';			
			}
		}
	}
}

function ing_cats(	$nostyle = false )
{
	global $post;
	$cats = get_the_category( $post->ID );
	if(empty($cats)) return;
	$return = '';
	
	if(!empty($cats))
	{
		foreach( $cats as $cat ) 
		{
			$return .='<li><a href="'.get_category_link( $cat->term_id ).'" '.($nostyle === true ? '' : 'class="tiny button secondary"').'>'.$cat->name.'</a></li>';
		}
	}
	
	return $return;
}

function ing_essentials()
{
	$ing_options = ingleside_options();
	
	$essentials = array(
		'admin_bar' => is_admin_bar_showing(),
		'logo_url' => !empty($ing_options['topbar']['logo']) ? $ing_options['topbar']['logo'] : false,
		'top_pin' => !empty($ing_options['topbar']['pin']) ? $ing_options['topbar']['pin'] : false,
		'sidebar_pin' => !empty($ing_options['sidebar']['pin']) ? $ing_options['sidebar']['pin'] : false,
		'sidebar_location' => !empty($ing_options['sidebar']['location']) ? $ing_options['sidebar']['location'] : 'right',
		'front_page' => is_front_page(),
		'follow' => isset($ing_options['topbar']['follow_enable']) && $ing_options['topbar']['follow_enable'] == 1 && !empty($ing_options['topbar']['follow_us']),
		'top_height' => !empty($ing_options['topbar']['height']),
		'mobile_top_height' => !empty($ing_options['topbar']['mobile_height']) ? (int)$ing_options['topbar']['mobile_height'] : '',
		'token' => wp_create_nonce("lakeview"),
		'ajaxurl' => admin_url('admin-ajax.php'),
	);
	
	
	if( !empty($ing_options['topbar']['logo']) )
	{
		if( empty($ing_options['topbar']['logo_size']) ){
		
			$size = ing_get_logo_size($ing_options['topbar']['logo']);
			
			$essentials['logo']['width'] = $size['width'];
			$essentials['logo']['height'] = $size['height'];
			
		}else{
		
			$size = $ing_options['topbar']['logo_size'];
			$essentials['logo']['width'] = $size['width'];
			$essentials['logo']['height'] = $size['height'];
		}

	}else{
		$essentials['logo'] = '';
	}
	
	
	if( empty($ing_options) ){
		$essentials['init'] = false;
	}else{
		$essentials['init'] = true;
	}
	
	return $essentials;
}

function ing_sidebar_classes()
{
	$ing_options = ingleside_options();
	
	$classes = array(
		'main-content' => 'style="max-width: 100%;"',
		'primary' => 'large-9 medium-9 columns',
		'sidebar' => 'large-3 medium-3 columns'
	);
	
	if(!empty($ing_options['sidebar']['location'])){
		if($ing_options['sidebar']['location'] == 'none'){
			//$classes['main-content'] = '';
			$classes['main-content'] = ( !empty($ing_options['home']['ingleside']['fullwidth']) ? 'style="max-width: 100%;"' : '');
			$classes['primary'] = 'large-12 medium-12 columns';
			$classes['sidebar'] = 'hide';
			$classes['footer'] = 'large-12 medium-12 columns';
		}elseif($ing_options['sidebar']['location'] == 'right'){
			$classes['primary'] = 'large-9 medium-9 columns';
			$classes['sidebar'] = 'large-3 medium-3 columns';
		}elseif($ing_options['sidebar']['location'] == 'left'){
			$classes['primary'] = 'large-9 large-push-3 medium-9 medium-push-3 columns';
			$classes['sidebar'] = 'large-3 large-pull-9 medium-3 medium-pull-9 columns';	
		}
	}elseif(empty($ing_options['sidebar']['location'])){
		$classes['primary'] = 'large-9 medium-9 columns';
		$classes['sidebar'] = 'large-3 medium-3 columns';
	}
	
	return $classes;
}

function ingleside_options()
{
	$options = array();
	
	if(is_customize_preview()){
		$options = get_option( 'ing_theme_options' );
		$options = array_map_recursive( 'esc_attr', $options );
	}
	else
	{
		//delete_option('ing_theme_options');
		//delete_transient( 'ingleside_options' );
		if ( false === ( $value = get_transient( 'ingleside_options' ) ) ) {
			$check = get_option( 'ing_theme_options' );

			if( !empty($check) ){
				$check = array_map_recursive('esc_attr', $check);
				set_transient( 'ingleside_options', $check, 240 );
				$options = get_option('ing_theme_options');
			}
		}else{
			$options = get_transient( 'ingleside_options' );
		}
	}

	return $options;
}

function array_map_recursive( $callback, $array ) 
{
	if(empty($array)) return;
	
    foreach ($array as $key => $value) {
        if (is_array($array[$key])) {
            $array[$key] = array_map_recursive($callback, $array[$key]);
        }
        else {
            $array[$key] = call_user_func($callback, $array[$key]);
        }
    }
    return $array;
}
?>