<?php
function ing_homepage($classes, $ing_options)
{
	global $post;
	
	if( isset($ing_options['home']['select']) && 'ingleside' === $ing_options['home']['select'] && isset($ing_options['home']['ingleside']['content']) )
	{
		$full_width = '';
		$sort = array();
		$posts_per_page = -1;
		
		if( isset($ing_options['home']['ingleside']['fullwidth']) ){
			if( !empty($ing_options['home']['ingleside']['fullwidth']) ){
				$full_width = 'style="max-width:100%;"';
			}
		}
	
	?>
	<div id="main-content" class="row collapse" <?php echo $full_width;?>>
		<div id="primary" class="large-12 medium-12 small-12 columns">
		<?php
		$sort = explode( ',',esc_attr($ing_options['home']['ingleside']['content']) );
		$posts_per_page = count($sort);
		
		$query = get_posts(array( 
					'posts_per_page' => $posts_per_page,
					'post_type' => 'any',
					'post__in' => $sort,
					'orderby' => 'post__in'
				));
				
			
		if( !empty($query) )
		{
			foreach ( $query as $post )
			{
				setup_postdata( $post );
				get_template_part( 'content', 'ingleside' );
			}  
		}
		else
		{
			get_template_part( 'content', 'none' );
		}
			
		wp_reset_postdata();
		?>
		</div>
	</div>	
	<?php
	}
	else
	{
	?>
	<div id="main-content" class="row collapse" <?php echo $classes['main-content'];?>>
		<div id="primary" class="<?php echo $classes['primary'];?>">
		<?php
		if(have_posts())
		{
			while ( have_posts() )
			{
				the_post();
				
				get_template_part( 'content', 'archive' );
			}
			?>
			<div class="ing-navigation clearfix">
				<div class="left"><?php previous_posts_link( '<i class="fi-previous"></i>' ); ?></div>
				<div class="right"><?php next_posts_link( '<i class="fi-next"></i>', '' ); ?></div>
			</div>
			<?php			
		}else{
			get_template_part( 'content', 'none' );
		}
		
		?>
		</div>
		<?php get_sidebar(); ?>
	</div>	
	<?php
	}

}

function ing_head()
{
	$ing_options = ingleside_options();
	echo'
	<nav class="top-bar" data-topbar role="navigation">
		<ul class="title-area">
			<li class="name">
				<h1><a href="',home_url(),'">';
				if(!empty($ing_options['topbar']['logo'])){
					echo '<img src="',esc_url($ing_options['topbar']['logo']),'" alt="',get_bloginfo('name'),'" alt="',get_bloginfo('name'),'" />';
				}else{
					echo get_bloginfo('name');
				}
				echo
				'</a></h1>
			</li>
			<li class="toggle-topbar menu-icon"><a href="#"><span>Menu</span></a></li>
		</ul>

		<section class="top-bar-section">
			<ul class="site-description left">';
			
			if( !empty($ing_options['topbar']) )
			{
				if( !empty($ing_options['topbar']['tagline']) ){
					echo'<li class="has-form desc"><h2>',get_bloginfo('description'),'</h2></li>';
				}
			}else{
				echo '<li class="has-form hide-for-small"><h2>',get_bloginfo('description'),'</h2></li>';
			}
			
			if(!is_customize_preview()){
				ing_follow($mobile = true);
			}
			echo'
			</ul>';		

			wp_nav_menu(array(
		    	'container' => false,
		    	'menu' => __( 'Main Menu', 'inglesideterrace' ),
		    	'menu_class' => 'right',
		    	'theme_location' => 'main-menu',
		        'walker' => new F5_TOP_BAR_WALKER(),
			));
		
		echo'
		</section>
	</nav>';
}

function ing_cta($ing_options)
{	
	if(is_customize_preview())
	{
		$cta_id = !empty($ing_options['content']['cta']['id']) ? esc_attr($ing_options['content']['cta']['id']) : null;
		if( !is_numeric($cta_id) ) {return;}
			
		$custom_query = new WP_Query( 
			array(
				'page_id' => (int)$ing_options['content']['cta']['id'],
				'post_status' => array( 'publish', 'draft'),
				)
			);
		
		if(empty($custom_query->post)) {return;}
		
		return '<div id="ing-call-to-action">'.apply_filters('the_content',$custom_query->post->post_content).'</div>';
	}
	else
	{
		if( isset($ing_options['content']['cta']['id']) )
		{
			if( !empty($ing_options['content']['cta']['id']) && !empty($ing_options['content']['cta']['content']) ){
			
				if( !is_numeric($ing_options['content']['cta']['id']) ) {return;}
				
				return '<div id="ing-call-to-action">'.apply_filters( 'the_content',htmlspecialchars_decode( stripslashes($ing_options['content']['cta']['content'] ) ) ).'</div>';
			}
		}
	}
}

function ing_footer()
{
	$widgets = wp_get_sidebars_widgets(); //move to essentials?
	if(isset($widgets['ing-footer'])){
		$widget_count = count( $widgets['ing-footer'] );
	}else{
		$widget_count = 3;
	}
	
	echo '
	<footer id="bottom">
		<div class="row">
			<div class="large-12 medium-12 columns">
				<ul class="ing-footer-widgets small-block-grid-1 large-block-grid-',$widget_count,' medium-block-grid-',$widget_count,'">';
				dynamic_sidebar( 'ing-footer' );
				echo'
				</ul>
			</div>
		</div>
		<div class="copy">&copy; ',date('Y'), ' ', get_bloginfo('name'),'</div>
	</footer>';
}

function header_style()
{
	$ing_options = ingleside_options();
	
	$size = array(
		'width' => '',
		'height' => '',
	);
	
	$logic = array(
		'follow_no_logo' => !empty($ing_options['topbar']['follow_enable']) && empty($ing_options['topbar']['logo']),
		'has_logo' => !empty($ing_options['topbar']['logo']),
		'pinned' => !empty($ing_options['topbar']['pin']),
		'logo_has_size' => !empty($ing_options['topbar']['logo_size']),
	
	);
		
	if( $logic['has_logo'] )
	{
		if( $logic['logo_has_size'] ){
			$size = $ing_options['topbar']['logo_size'];
		}else{
			$size = ing_get_logo_size($ing_options['topbar']['logo']);
		}
	}
	
	$follow = isset($ing_options['topbar']['follow_enable']) && 1 == (int)$ing_options['topbar']['follow_enable'] && !empty($ing_options['topbar']['follow_us']) && !empty($ing_options['topbar']['follow']);
	
	echo '
	<style type="text/css">';
	if( isset($ing_options['topbar']['pin']) )
	{
		if( $logic['pinned'] )
		{
			echo'
			header#top{
				position: fixed;
				top: ',(is_admin_bar_showing() ? '32px' : '0px'),';
			}';
		}
	}
	else
	{
		echo'
		@media only screen 
		and (max-width: 40em){ 
			#wrap{
				margin-top: 45px;
			}
		}
		
		header#top{
			position: fixed;
			top: ',(is_admin_bar_showing() ? '32px' : '0px'),';
		}';
	}
		
		echo'
		@media only screen and (min-width: 40.063em) {
			.top-bar{ 
				height: auto;
			}';

	if( isset($ing_options['topbar']['pin']) )
	{
		if( $logic['pinned'] )
		{
			echo'
			#wrap{';
			if( $logic['has_logo'] ){
				if((int)$size['height'] <= 45)
				{
					if($follow){
						if(!empty($ing_options['topbar']['height'])){
							echo'margin-top:',((int)$ing_options['topbar']['height']+32),'px;';
						}else{
							echo'margin-top:77px;';
						}
					}else{
						//echo'margin-top:45px;';
						if(!empty($ing_options['topbar']['height'])){
							echo'margin-top:44px;';
						}
					}
				}
				else
				{
					if($follow){
						if(!empty($ing_options['topbar']['height'])){
							echo'margin-top:',((int)$ing_options['topbar']['height']+32),'px;';
						}
					}else{
						if(!empty($ing_options['topbar']['height'])){
							echo'margin-top:',(int)$ing_options['topbar']['height'],'px;';
						}
					}
				}
			}else{
				
				if($follow){
					if(!empty($ing_options['topbar']['height'])){
						echo'margin-top:',((int)$ing_options['topbar']['height']+32),'px;';
					}
				}else{
					if(!empty($ing_options['topbar']['height'])){
						echo'margin-top:',(int)$ing_options['topbar']['height'],'px;';
					}
				}
			
			}
			echo'
			}
		}';
		
		echo'
		@media only screen 
and (min-device-width : 768px) 
and (max-device-width : 1024px)  {
			.top-bar{ 
				height: auto;
			}
			#wrap{';
			if(!empty($ing_options['topbar']['pin']) && 1 == (int)$ing_options['topbar']['pin'])
		{
				if($follow){
					if(!empty($ing_options['topbar']['mobile_height'])){
						echo'margin-top:',((int)$ing_options['topbar']['mobile_height']+32),'px;';
					}
				}
				else
				{
					if(!empty($ing_options['topbar']['mobile_height'])){
						echo'margin-top:',(int)$ing_options['topbar']['mobile_height'],'px;';
					}else{
						echo 'margin-top:45px;';
					}
				}

			
			}
			echo'
			}
		}';
		}
	}
	else
	{
		if($logic['follow_no_logo']){
			echo '
			#wrap{
				margin-top:80px;
			}';
		}else{
			echo '
			#wrap{
				margin-top:45px;
			}';
		}

	}
	
	if(!empty($ing_options['palette']['topbar']['background_color']))
	{
		echo'
		header#top,
		.top-bar-section .dropdown{
			background: ',$ing_options['palette']['topbar']['background_color'],';
		}';
	}
	
	if(!empty($ing_options['palette']['topbar']['opacity']))
	{
		echo'
		header#top{
			opacity: ',$ing_options['palette']['topbar']['opacity'],';
		}';
	}
	
	if(!empty($ing_options['palette']['topbar']['bw']))
	{
		echo'
		.top-bar-section>ul>li:not(.has-form) a:not(.button):hover,
		.top-bar-section li.active:not(.has-form) a:not(.button),
		.top-bar-section li.active:not(.has-form) a:not(.button):hover{
			background: rgb(',$ing_options['palette']['topbar']['darken'],');
			color: ',$ing_options['palette']['topbar']['bw'],';
		}
		
		.top-bar-section ul li>a,
		.top-bar-section ul li:hover>a,
		.top-bar-section .dropdown li a,
		.top-bar .site-description h2,
		.top-bar .name h1 a,
		header#top .ing-follow .inline-list li a{
			color: ',$ing_options['palette']['topbar']['bw'],';
		}
		
		header#top .ing-follow .inline-list li a:hover{
			opacity:0.5;
		}
		
		.top-bar-section .has-dropdown > a::after{
			border-color: ',$ing_options['palette']['topbar']['bw'],' transparent transparent transparent;
		}
		
		.top-bar-section .dropdown li:not(.has-form):not(.active) > a:not(.button),
		.top-bar-section>ul>li:not(.has-form) a:not(.button),
		header#top .ing-follow .inline-list li a
		{
			color: ',$ing_options['palette']['topbar']['bw'],';
		}
		
		.top-bar-section .dropdown li:not(.has-form):not(.active):hover>a:not(.button),
		.top-bar-section ul li:hover:not(.has-form)>a
		{
			background: rgb(',$ing_options['palette']['topbar']['darken'],');
			color: ',$ing_options['palette']['topbar']['bw'],';
		}';
	}
	
	if(!empty($ing_options['topbar']['logo']))
	{
		if((int)$size['height'] <= 45)
		{
			echo'
			.top-bar .title-area .name img
			{
				/*margin-top: -5px;*/
			}
			
			.top-bar .title-area .name a
			{
				padding: 0px 15px 5px;
			}
			';
		}
		else
		{
			echo '			
			header#top
			{';
				if($follow){
					echo 'height: ',((int)$size['height']+32),'px;';
				}else{
					echo 'height: ',(int)$size['height'],'px;';
				}
			echo'
			}
			
			
			.top-bar{
				top: ',(int)$size['height'] - 45,'px;
			}
			
			.top-bar .title-area .name
			{
				position: absolute;
				width: ',(int)$size['width'],'px;
				height: ',(int)$size['height'],'px;
				bottom:-45px;
			}
			
			
			ul.site-description.left{
				margin-left: ',(int)$size['width'],'px;
				margin-top: -50px;
			}
			
			@media only screen 
			and (min-width: 40.063em) 
			and (max-width: 64em) 
			{ 
				ul.site-description.left{
					margin-top: -', ((int)$size['height'] / 2) + 20,'px;
					margin-top: -60px;
				}
			}
			
			@media only screen 
			and (max-width: 40em) 
			{ 
				ul.site-description.left{
					margin-top: 0px;
				}
				
				header#top{
					height: initial;
				}
				
				.top-bar{
					top: 0;
				}
				
				.top-bar .title-area .name
				{
					position:relative !important;
					width: auto;
					height: 45px;
					bottom:0;
				}
				
				.top-bar .name h1 a img{
					height: 45px;
				}
				
				.top-bar-section ul{';
				if(!empty($ing_options['palette']['topbar']['background_color']))
				{
					echo'background: ',$ing_options['palette']['topbar']['background_color'],';';
				}
			echo'
				}
			}';
		}
	}
	echo'
	</style>';
}

add_action('wp_head','header_style');

function link_style()
{
	$ing_options = ingleside_options();
	
	if(empty($ing_options['palette']['content'])) return;
	
	echo '
	<style type="text/css">';
	if(!empty($ing_options['palette']['links']['background_color'])){
		echo'
		footer#bottom a,
		#sidebar a,
		.entry-title a, 
		.entry-content a:not(.button),
		.widget_calendar a,
		a.url.fn.n,
		.entry-date a{
			color: ',$ing_options['palette']['links']['background_color'],';
		}';
	}
	
	if( !empty( $ing_options['palette']['links']['complement']) ){
		echo'
		footer#bottom a:hover,
		#sidebar a:hover,
		.entry-title a:hover, 
		.entry-content a:not(.button):hover,
		.widget_calendar a:hover,
		a.url.fn.n:hover,
		.entry-date a:hover{
			color: rgb(',$ing_options['palette']['links']['complement'],');
		}';
	}
	
	echo'
	</style>';
}

add_action('wp_head','link_style');

function content_style()
{
	$ing_options = ingleside_options();
	
	if(empty($ing_options['palette']['content'])) return;
	
	echo '
	<style type="text/css">';
	if(!empty($ing_options['palette']['content']['title']['background_color'])){
		echo'
		.entry-title,
		.entry-title a{
			color: ',$ing_options['palette']['content']['title']['background_color'],';
		}';
	}
	
	if(!empty($ing_options['palette']['content']['title']['background_color'])){
		echo'
		.entry-title a:hover{
			color: rgb(',$ing_options['palette']['content']['title']['complement'],');
		}';
	}
	
	if(!empty($ing_options['palette']['content']['header']['background_color'])){
		echo'
		.entry-content h1,.entry-content h2,.entry-content h3,.entry-content h4,.entry-content h5,.entry-content h6,
		.entry-content h1 a,.entry-content h2 a,.entry-content h3 a,.entry-content h4 a,.entry-content h5 a,.entry-content h6 a{
			color: ',$ing_options['palette']['content']['header']['background_color'],';
		}';
	}
	
	if(!empty($ing_options['palette']['content']['header']['background_color'])){
		echo'
		.entry-content h1 a:hover,.entry-content h2 a:hover,.entry-content h3 a:hover,.entry-content h4 a:hover,.entry-content h5 a:hover,.entry-content h6 a:hover{
			color: rgb(',$ing_options['palette']['content']['header']['complement'],');
		}';
	}

	if(!empty($ing_options['palette']['content']['paragraph']['background_color'])){
		echo'
		.entry-content p,
		td{
			color: ',$ing_options['palette']['content']['paragraph']['background_color'],';
		}';
	}
	
	if(!empty($ing_options['palette']['content']['breadcrumbs']['background_color'])){
		echo'
		.breadcrumbs,
		.ing-tags span.label{
			background-color: ',$ing_options['palette']['content']['breadcrumbs']['background_color'],';

		}';
	}
	
	if(!empty($ing_options['palette']['content']['breadcrumbs']['darken']) && !empty($ing_options['palette']['content']['breadcrumbs']['bw'])){
		echo'
		.breadcrumbs{
			border-color: ',$ing_options['palette']['content']['breadcrumbs']['darken'],';
		}
		
		.breadcrumbs li a,.breadcrumbs li time,.ing-tags span.label a{
			color: ',$ing_options['palette']['content']['breadcrumbs']['bw'],';
		}';
	}
	

	if(!empty($ing_options['palette']['content']['sharing']['background_color'])){
		echo'
		.icon-bar{
			background-color: ',$ing_options['palette']['content']['sharing']['background_color'],';
		}';
	}
	
	if(!empty($ing_options['palette']['content']['sharing']['contrast']) && !empty($ing_options['palette']['content']['sharing']['bw'])){
		echo'
		.icon-bar > * i{
			color: ',$ing_options['palette']['content']['sharing']['bw'],';
		}
		.icon-bar > *:hover{
			background: rgb(',$ing_options['palette']['content']['sharing']['contrast'],');
		}';
	}

	if(!empty($ing_options['palette']['content']['columns']['background_color'])){
		$bgi = get_background_image();
		$bg = get_background_color();
		
		if(!empty($bgi)){
			$bc = 'border: 2px solid transparent; border-image: url('.$bgi.') 2 2;';
		}elseif(!empty($bg)){
			$bc = 'border: 2px solid #'.$bg.';';
		}elseif(empty($bg)){
			$bc = 'border: 2px solid white;';
		}
				
		echo'
		.ingcols > li{
			background-color: ',$ing_options['palette']['content']['columns']['background_color'],';',
			$bc,'
		}';
	}
	
	if(!empty($ing_options['palette']['content']['columns']['bw']) && !empty($ing_options['palette']['content']['columns']['complement'])){
		echo'
		.ingcols > li h1,.ingcols > li h2,.ingcols > li h3,.ingcols > li h4,.ingcols > li h5,.ingcols > li h1 a,.ingcols > li h2 a,.ingcols > li h3 a,.ingcols > li h4 a,.ingcols > li h5 a,.ingcols > li p
		{
			color: ',$ing_options['palette']['content']['columns']['bw'],';
		}
		.ingcols > li h1 a:hover,.ingcols > li h2 a:hover,.ingcols > li h3 a:hover,.ingcols > li h4 a:hover,.ingcols > li h5 a:hover
		{
			color: rgb(',$ing_options['palette']['content']['columns']['complement'],');
		}';
	}
	
	echo'
	</style>';
}

add_action('wp_head','content_style');


function comment_style()
{
	$ing_options = ingleside_options();
	
	if(empty($ing_options['palette']['comments'])) return;
	
	echo '
	<style type="text/css">';
	if(!empty($ing_options['palette']['comments']['background_color'])){
		echo'
		.comment.list .comment{
			background-color: ',$ing_options['palette']['comments']['background_color'],';
		}';
	}
	
	if(!empty($ing_options['palette']['comments']['bw'])){
		echo'
		.comment.list,.comment.list a:not(.button),.comment.list p,.comment.list h1,.comment.list h2,.comment.list h3,.comment.list h4,.comment.list h5,.comment.list h6,cite{
			color: ',$ing_options['palette']['comments']['bw'],';
		}
		
		.comment.list .comment{
			border-color: ',$ing_options['palette']['comments']['bw'],';
		}';
	}
	echo'
	</style>';
}

add_action('wp_head','comment_style');

function button_style()
{
	$ing_options = ingleside_options();
	
	if(empty($ing_options['palette']['buttons'])) return;
	
	$buttons = array(
		'secondary' => array(
			'border' => '#b9b9b9'
		),
		'success' => array(
			'border' => '#368a55'
		),
		'alert' => array(
			'border' => '#cf2a0e'
		),
	);
	
	echo '
	<style type="text/css">';
	if(!empty($ing_options['palette']['buttons']['ghost']))
	{
		echo'
		input#searchsubmit.button.tiny{
			padding: 0.5rem 1.25rem 0.45rem 1.25rem;
		}';
	}
	
	$c = ing_crunch_button_colors($ing_options);
		
	echo'	
	.button:not(.secondary):not(.success):not(.alert),
	ul.pagination li.current a{
		border-width: ',$c['border-width'],';
		background-color: ',$c['background'],';
		border-color: ',$c['darken'],';
	}';
	
	echo'
	.button:not(.secondary):not(.success):not(.alert){
		color: ',$c['bw'],';
	}';
	
	echo'
	.button:not(.secondary):not(.success):not(.alert):hover{
		background-color: ',$c['background-hover'],';
		color: white;
		border-color: ',$c['background-hover'],';
	}
	
	.stack-for-small .button:not(.secondary):not(.success):not(.alert){
		border-width: ',$c['background'],';
	}
	
	.button-group.round.stack-for-small > * > button, 
	.button-group.round.stack-for-small > * .button{
		border-left: 0px;
		border-right: 0px;
	}
	
	.button-group.round.stack-for-small > * > button:first-child, 
	.button-group.round.stack-for-small > * .button:first-child{
		border-left: ',$c['border-width'],';
		border-right: 0px;
	}
	
	.button-group.round.stack-for-small > * > button:last-child, 
	.button-group.round.stack-for-small > * .button:last-child{
		border-left: 0px;
		border-right: ',$c['border-width'],';
	}';
	
	foreach($buttons as $button => $attr)
	{
		$c = ing_crunch_button_colors($ing_options,$button);
				
		echo'
		.button.',$button,'{
			background-color: ',$c['background'],';
			border-width: ',$c['border-width'],';
			border-color: ',$c['darken'],';
		}
		
		.button.',$button,':hover{
			background-color: ',$c['background-hover'],';
			border-color: ',$c['background-hover'],';
			color: ',$c['bw-hover'],';
		}';	

		echo'
		.button.',$button,'{
			color: ',$c['bw'],';
		}'; //!ternary
		
		echo'
		a.button.tiny.',$button,'.disabled{
			border-color: ',$c['darken'],';
			background-color: ',$c['background'],';
		}
		
		.stack-for-small a.button.tiny'.'.'.$button.'{
			border-color: ',$c['darken'],';
			background-color: ',$c['background'],';
		}
		
		.stack-for-small a.button.tiny'.'.'.$button.':hover{
			background-color: ',$c['background-hover'],';
			border-color: ',$c['background-hover'],';
		}
		';
		
	}
	
/*
	if(!empty($ing_options['palette']['buttons']['ghost']))
	{
		echo'
		.button:not(.secondary):not(.success):not(.alert),
		ul.pagination li.current a{
			border-width: 3px;
			background-color: transparent;';
			if(!empty($ing_options['palette']['buttons']['primary']['darken'])){
				echo'
				border-color: ',$ing_options['palette']['buttons']['primary']['darken'],';';
			}else{
				echo 'border-color: #007095;';
			}
			echo'
		}';
		
		if(!empty($ing_options['palette']['buttons']['primary']['bw'])){
			echo'
			.button:not(.secondary):not(.success):not(.alert){
				color: ',$ing_options['palette']['buttons']['primary']['bw'],';
			}';
		}else{
			echo'
			.button:not(.secondary):not(.success):not(.alert){
				color: #007095;
			}';
		}	
	}
	else
	{
		if(!empty($ing_options['palette']['buttons']['primary']['darken'])){
			echo'
			.button:not(.secondary):not(.success):not(.alert),
			ul.pagination li.current a{
				background-color: ',$ing_options['palette']['buttons']['primary']['background_color'],';';
				if(!empty($ing_options['palette']['buttons']['primary']['darken'])){
					echo'
					border-color: ',$ing_options['palette']['buttons']['primary']['darken'],';';
				}
				echo'
			}';
		}
	
		if(!empty($ing_options['palette']['buttons']['primary']['bw'])){
			echo'
			.button:not(.secondary):not(.success):not(.alert){
				color: ',$ing_options['palette']['buttons']['primary']['bw'],';
			}';
		}
	}
	
	if(!empty($ing_options['palette']['buttons']['primary']['darken'])){
		echo'
		.button:not(.secondary):not(.success):not(.alert):hover{
			background-color: rgb(',$ing_options['palette']['buttons']['primary']['darken'],');
		}';
	}else{
		echo'
		.button:not(.secondary):not(.success):not(.alert):hover{
			background-color: #007095;
			color: white;
		}';
	}
	
	foreach($buttons as $button => $attr)
	{
		if(!empty($ing_options['palette']['buttons'][$button]['background_color'])){
			if(!empty($ing_options['palette']['buttons']['ghost'])){
				echo'
				.button.',$button,'{
					background-color: transparent;
					border-width: 3px;
				}';	
			}else{
				echo'
				.button.',$button,'{
					background-color: ',$ing_options['palette']['buttons'][$button]['background_color'],';
				}';				
			}

		}
		
		if(!empty($ing_options['palette']['buttons'][$button]['darken'])){
			echo'
			.button.',$button,'{
				border-color: ',$ing_options['palette']['buttons'][$button]['darken'],';
			}';
		}
		
		if(!empty($ing_options['palette']['buttons']['ghost']))
		{
			echo'
			.button.',$button,'{';
			if(!empty($ing_options['palette']['buttons'][$button]['darken'])){
				echo 'color: ',$ing_options['palette']['buttons'][$button]['darken'],';';
			}else{
				echo 'color:', $attr['border'], ';';
			}
			echo'	
			}';
			
			echo'
			.button.',$button,':hover{
				color: ';
				if($ing_options['palette']['buttons'][$button]['background_color'] == '#43ac6a'){
					echo 'white';
				}else{
					echo $ing_options['palette']['buttons'][$button]['bw'],';';
				}
				echo'
			}';
		}
		else
		{
			if(!empty($ing_options['palette']['buttons'][$button]['bw'])){
			
				echo'
				.button.',$button,',
				.button.',$button,':hover{
					color: ';
					if($ing_options['palette']['buttons'][$button]['background_color'] == '#43ac6a'){
						echo 'white';
					}else{
						echo $ing_options['palette']['buttons'][$button]['bw'],';';
					}
					echo'
				}';
			}	
		}

		if(!empty($ing_options['palette']['buttons'][$button]['darken'])){
			echo'
			.button.',$button,':hover{
				background-color: rgb(',$ing_options['palette']['buttons'][$button]['darken'],');
			}';
		}
	
	}
	*/
	echo'
	</style>';
}

add_action('wp_head','button_style');

function sidebar_style()
{	
	$ing_options = ingleside_options();
	
	$size = array(
		'width' => '',
		'height' => '',
	);
	
	if( isset($ing_options['sidebar']['pin']) )
	{
			echo '
	<style type="text/css">';
		if( !empty($ing_options['sidebar']['pin']) )
		{
			echo'
			#sidebar{
				position: fixed;';
				if(!empty($ing_options['sidebar']['location'])){
					if( 'right' == esc_attr($ing_options['sidebar']['location']) ){
						echo 'right: 0;';
					}elseif( 'left' == esc_attr($ing_options['sidebar']['location'])){
						//echo 'left: 0;';
					}else{
						echo 'right: 0;';
					}
				}
				if(!empty($ing_options['topbar']['logo'])){
					
				}else{
					is_admin_bar_showing() ? 'top: 77px;' : 'top: 45px;';
				}
			echo'}';
			
			if(is_front_page())
			{
				if(ing_cta($ing_options) != ''){
					echo'
					#sidebar{
						position: relative;
					}';
				}else{
					echo'
					#sidebar{
						position: fixed;';
						if( !empty($ing_options['topbar']['logo']) ){
							$offset = !is_admin_bar_showing() ?: 32;
							echo'top:',$ing_options['topbar']['height'] + $offset,'px;';
						}
						echo'
					}';
				}
			}
		}
		echo'
		</style>';
	}
			
	if( empty($ing_options['palette']['sidebar']) ){ return; }
	
	echo '
	<style type="text/css">
		#sidebar{
			background: ',$ing_options['palette']['sidebar']['background_color'],';';
			if(!empty($ing_options['palette']['sidebar']['bw'])){
				echo 'color: ',$ing_options['palette']['sidebar']['bw'],';';
			}
			echo'
		}';
		
		if(!empty($ing_options['palette']['sidebar']['bw']))
		{
		echo'
		#sidebar ul>li a{
			color: ',$ing_options['palette']['sidebar']['bw'],';
			background: rgba(',$ing_options['palette']['sidebar']['darken'],',0.2);
		}
		
		#sidebar ul>li a:hover{
			color: ',$ing_options['palette']['sidebar']['bw'],';
			background: rgba(',$ing_options['palette']['sidebar']['contrast'],',0.2);
		}
		
		#sidebar h3.widgettitle{
			color: ',$ing_options['palette']['sidebar']['bw'],';
		}
		
		#sidebar .tagcloud a{
			color: ',$ing_options['palette']['sidebar']['bw'],';
		}';
		}
		
		if(!empty($ing_options['palette']['sidebar']['complement'])){
			echo'
			#sidebar .tagcloud a:hover{
				color: rgba(',$ing_options['palette']['sidebar']['complement'],',1);
			}';
		}

		echo'
		@media only screen and (min-width: 40.063em) {';
			
			if(!empty($ing_options['topbar']['logo']))
			{
				if( !empty($ing_options['topbar']['logo_size']) ){
					$size = $ing_options['topbar']['logo_size'];
				}else{
					$size = ing_get_logo_size( $ing_options['topbar']['logo'] );
					
				}
			}

		echo'
		}
	</style>';
}


add_action('wp_head','sidebar_style');

function footer_style()
{
	$ing_options = ingleside_options();
	if(empty($ing_options['palette']['footer'])) return;
	if($ing_options['palette']['footer']['background_color'])
	{
		echo '
		<style type="text/css">
		footer#bottom{
			background: ',$ing_options['palette']['footer']['background_color'],';
			
		}
		
		.ing-navigation a{
			color: ',$ing_options['palette']['footer']['background_color'],';
		}
		
		footer#bottom .ing-widgets ul>li a{
			background: rgba(',$ing_options['palette']['footer']['darken'],',0.2);
		}
		footer#bottom .ing-widgets ul>li a:hover{
			background: rgba(',$ing_options['palette']['footer']['contrast'],',0.2);
		}
		
		.ing-navigation a:hover{
			color: rgba(',$ing_options['palette']['footer']['contrast'],',0.2);
		}
		
		';
		
		if(!empty($ing_options['palette']['footer']['bw'])){
			echo '
			footer#bottom,
			footer#bottom .ing-widgets ul>li a,
			footer#bottom .ing-widgets h3.widgettitle,
			footer#bottom .ing-widgets h1,
			footer#bottom .ing-widgets h2,
			footer#bottom .ing-widgets h3,
			footer#bottom .ing-widgets h4,
			footer#bottom .ing-widgets h5,
			footer#bottom .ing-widgets h6,
			footer#bottom .tagcloud a{
				color: ',$ing_options['palette']['footer']['bw'],';
			}';
		}
		
		if(!empty($ing_options['palette']['footer']['complement'])){
			echo '
			footer#bottom .tagcloud a:hover{
				color: rgb(',$ing_options['palette']['footer']['complement'],');
			}';
		}
		
		echo'
		@media only screen and (min-width: 40.063em) {';
		if(!empty($ing_options['sidebar']['pin']) && 1 == (int)$ing_options['sidebar']['pin']){
			if(!empty($ing_options['sidebar']['location'])){
				if( 'left' == $ing_options['sidebar']['location']){
					echo'
					footer#bottom{
						float: right;';
						switch(true)
						{
							case( is_home() && !empty( $ing_options['content']['cta']['id'] ) ):
							echo 'width: 100%;';
							break;
							
							default:
							echo 'width: 75%;';
						}
					echo'
					}';
					
					echo'
					footer#bottom:after { 
					   content: "."; 
					   visibility: hidden; 
					   display: block; 
					   height: 0; 
					   clear: both;
					}';
				}elseif( 'none' == $ing_options['sidebar']['location']){
					echo'
					footer#bottom{
						width: 100%;
					}';
				}elseif( 'right' == $ing_options['sidebar']['location']){
					echo'
					footer#bottom{';
						switch(true)
						{
							case( is_home() && !empty( $ing_options['content']['cta']['id'] ) ):
							echo 'width: 100%;';
							break;
							
							default:
							echo 'width: 75%;';
						}
					echo'
					}';
				}
			}
		}
		echo'
		}';

		echo'
		</style>';
	}
}

add_action('wp_head','footer_style');

?>