=== Lonely Road ===
Contributors: dbeja
Donate link: http://dbeja.com/
Tags: responsive-layout, two-columns, custom-colors, custom-menu, featured-images, translation-ready, theme-options, light, gray, right-sidebar, custom-background, post-formats, sticky-post, threaded-comments
Requires at least: 3.5
Tested up to: 4.0
Stable tag: 1.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Lonely Road is a free responsive and clean Wordpress theme.

== Description ==

Lonely Road is a free responsive and clean Wordpress theme. It was developed using only css and icon fonts so it’s a very light theme. Make it your own with custom colours, a selection of Google Fonts, a custom logo, a custom background image and links to your social networks (icons included). Other features include featured images, responsive layout, sticky posts and sidebar widgets.

== Changelog ==

= 1.0 =

* Initial Release
