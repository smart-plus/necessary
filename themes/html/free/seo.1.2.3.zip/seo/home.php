<?php
/**
 * The Home template file.
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
  
  			<?php if ( get_theme_mod( 'seo_google_verification' ) ) : ?>
			<meta name="google-site-verification" content="<?php echo esc_html( get_theme_mod( 'seo_google_verification' ) ); ?>">
			<?php endif; ?> 

			<?php if ( get_theme_mod( 'seo_google_shortcut_icon' ) ) : ?>
			<link rel="shortcut icon" href="<?php echo esc_url( get_theme_mod( 'seo_google_shortcut_icon' ) ); ?>">	
			<?php endif; ?>

			<?php if ( get_theme_mod( 'seo_canonical' ) ) : ?>
			<link rel="canonical" href="<?php echo esc_url( get_theme_mod( 'seo_canonical' ) ); ?>">
			<?php endif; ?>  				
 			
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="hfeed site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'seo' ); ?></a>
	<div class="dotted">
		<header id="masthead" class="site-header" style="background: url('<?php header_image(); ?>') repeat; height:<?php echo get_custom_header()->height; ?>%;">	     
			<div class="site-branding">
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<p class="site-description"><?php bloginfo( 'description' ); ?></p>
			</div><!-- .site-branding -->	
			<div class="cont-nav">
					<nav>
						<div class="nav-ico">
						<a href="#" id="menu-icon">	
							<span class="menu-button"> </span>
							<span class="menu-button"> </span>
							<span class="menu-button"> </span>
						</a>
						 <?php
							wp_nav_menu ( array('theme_location' => 'menu-top',
							'container' => ''
						)); ?>
						</div>		
					</nav>
			</div><!-- #site-navigation -->

		</header><!-- #masthead -->
	</div>
	<div class="dotted">			
		<div class="seos-slide" style="background: url( <?php if ( get_theme_mod( 'seo_slide_img' ) ) { echo esc_url( get_theme_mod( 'seo_slide_img' ) ); } else {echo "<?php echo esc_url( home_url( '/' ) ); ?>/wp-content/themes/seo/img/header4.png";} ?> ); background-size: cover; background-repeat: no-repeat; background-position: center; min-width: 100%; " >
			<div class="slide">
				<div class="slide-url">
					<a href="<?php if ( get_theme_mod( 'seo_slide_url' ) ) { echo esc_html( get_theme_mod( 'seo_slide_url' ) ); } ?>">
						<h3 class="slide-title"><!-- #slide-title -->
							<?php if ( get_theme_mod( 'seo_slide_title' ) ) { echo esc_html( get_theme_mod( 'seo_slide_title' ) ) ; } ?>
						</h3>	
						<div class="slide-content"><!-- #slide-content -->
							<?php if ( get_theme_mod( 'seo_slide_content' ) ) { echo esc_html( get_theme_mod( 'seo_slide_content' ) ); } ?>	
						</div>
					</a>
				</div>			
			</div>		
		</div>
		</div>
	<div class="featured-box">	
	
		<div class="box seo-clear">
			<div class="box1 box-effect1">
					<?php if ( get_theme_mod( 'seo_slide_featured' ) ) : ?>
					<img alt="featured-img" src="<?php echo esc_html( get_theme_mod( 'seo_slide_featured' ) ); ?>" class="box-img1" />
					<?php endif; ?>	
					<img alt="featured-img" src="<?php echo esc_url( home_url( '/' ) ); ?>/wp-content/themes/seo/img/click.png" class="box-img1" />
				<div class="effect1">
					<h3 class="box-title1">
						<?php if ( get_theme_mod( 'seo_slide_featured_title' ) ) { echo esc_html( get_theme_mod( 'seo_slide_featured_title' ) ); } ?>	
					</h3>
					<div class="box-content1">
						<?php if ( get_theme_mod( 'seo_featured_content' ) ) : ?>
						<?php echo esc_html( get_theme_mod( 'seo_featured_content' ) ); ?>
						<?php endif; ?>	
					<?php if ( get_theme_mod( 'seo_slide_featured_url' ) ) : ?>
					<a class="read-more1" href="<?php echo esc_url( get_theme_mod( 'seo_slide_featured_url' ) ); ?>"><button type="button"><?php _e('Read more', 'seo'); ?></button></a>
					<?php endif; ?>	
					</div>
				</div>
			</div>	
		</div>
		
		<div class="box seo-clear">
			<div class="box1 box-effect1">
					<?php if ( get_theme_mod( 'seo_slide_featured1' ) ) : ?>
					<img alt="featured-img" src="<?php echo esc_html( get_theme_mod( 'seo_slide_featured1' ) ); ?>" class="box-img1" />
					<?php endif; ?>	
					<img alt="featured-img" src="<?php echo esc_url( home_url( '/' ) ); ?>/wp-content/themes/seo/img/click.png" class="box-img1" />
				<div class="effect1">
					<h3 class="box-title1">
						<?php if ( get_theme_mod( 'seo_slide_featured_title1' ) ) { echo esc_html( get_theme_mod( 'seo_slide_featured_title1' ) ); } ?>	
					</h3>
					<div class="box-content1">
						<?php if ( get_theme_mod( 'seo_featured_content1' ) ) : ?>
						<?php echo esc_html( get_theme_mod( 'seo_featured_content1' ) ); ?>
						<?php endif; ?>	
					<?php if ( get_theme_mod( 'seo_slide_featured_url1' ) ) : ?>
					<a class="read-more1" href="<?php echo esc_url( get_theme_mod( 'seo_slide_featured_url1' ) ); ?>"><button type="button"><?php _e('Read more', 'seo'); ?></button></a>
					<?php endif; ?>	
					</div>
				</div>
			</div>	
		</div>

		<div class="box seo-clear">
			<div class="box1 box-effect1">
					<?php if ( get_theme_mod( 'seo_slide_featured2' ) ) : ?>
					<img alt="featured-img" src="<?php echo esc_html( get_theme_mod( 'seo_slide_featured2' ) ); ?>" class="box-img1" />
					<?php endif; ?>	
					<img alt="featured-img" src="<?php echo esc_url( home_url( '/' ) ); ?>/wp-content/themes/seo/img/click.png" class="box-img1" />
				<div class="effect1">
					<h3 class="box-title1">
						<?php if ( get_theme_mod( 'seo_slide_featured_title2' ) ) { echo esc_html( get_theme_mod( 'seo_slide_featured_title2' ) ); } ?>	
					</h3>
					<div class="box-content1">
						<?php if ( get_theme_mod( 'seo_featured_content2' ) ) : ?>
						<?php echo esc_html( get_theme_mod( 'seo_featured_content2' ) ); ?>
						<?php endif; ?>	
					<?php if ( get_theme_mod( 'seo_slide_featured_url2' ) ) : ?>
					<a class="read-more1" href="<?php echo esc_url( get_theme_mod( 'seo_slide_featured_url2' ) ); ?>"><button type="button"><?php _e('Read more', 'seo'); ?></button></a>
					<?php endif; ?>	
					</div>
				</div>
			</div>	
		</div>	
	</div>	
	
	<div id="content" class="site-content">

	<div id="primary" class="content-area">
		<main id="main" class="site-main">
		
		<?php if ( have_posts() ) : ?>

			<?php /* Start the Loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>
			
			<div class="right">
				<?php get_template_part( 'template-parts/content', get_post_format() ); ?>
			</div>
			<?php endwhile; ?>

			<div class="nextpage"> <?php seo_pagination(); ?></div>

		<?php else : ?>
		<div class="right">
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		</div>
		<?php endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
