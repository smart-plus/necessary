<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package Seo
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

			<?php if ( get_theme_mod( 'seo_google_verification' ) ) : ?>
			<meta name="google-site-verification" content="<?php echo esc_html( get_theme_mod( 'seo_google_verification' ) ); ?>">
			<?php endif; ?>

			<?php if ( get_theme_mod( 'seo_google_shortcut_icon' ) ) : ?>
			<link rel="shortcut icon" href="<?php echo esc_url( get_theme_mod( 'seo_google_shortcut_icon' ) ); ?>">	
			<?php endif; ?> 
			

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="hfeed site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'seo' ); ?></a>
	<div class="dotted">
		<header id="masthead" class="site-header" style="background: url('<?php header_image(); ?>') repeat; height:<?php echo get_custom_header()->height; ?>%;">	     
			<div class="site-branding">
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<p class="site-description"><?php bloginfo( 'description' ); ?></p>
			</div><!-- .site-branding -->
			
			<div class="cont-nav">
					<nav>
						<div class="nav-ico">
						<a href="#" id="menu-icon">	
							<span class="menu-button"> </span>
							<span class="menu-button"> </span>
							<span class="menu-button"> </span>
						</a>
						 <?php
							wp_nav_menu ( array('theme_location' => 'menu-top',
							'container' => ''
						)); ?>
						</div>		
					</nav>
			</div><!-- #site-navigation -->

		</header><!-- #masthead -->
    </div>
	<div id="content" class="site-content">

	
	
	
	
	
	

	
	
	