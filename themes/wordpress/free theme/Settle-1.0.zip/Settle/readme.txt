Settle theme by FlexiThemes, https://flexithemes.com
Online Demo: https://flexithemes.com/demo/Settle/
Theme URI: https://flexithemes.com/settle-wordpress-theme/